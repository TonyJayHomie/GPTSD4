@echo off
setlocal EnableDelayedExpansion
title BUILD_LAUNCHER - JewlessLauncher.c ^> JewlessLauncher.exe

echo.
echo ============================================================
echo  JEWLESS SOCIETY - launcher-only build
echo  JewlessLauncher.c -^> JewlessLauncher.exe
echo  (this script does NOT build version.dll - launcher only)
echo ============================================================
echo.

:: ---------------------------------------------------------------
:: Step 1: locate vcvarsall.bat (VS 2022 / 2019 / 2017 / BuildTools)
:: ---------------------------------------------------------------
set "VCVARS="

:: Try vswhere first - always present with VS 2017+ installer
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"

if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%i in (
        `"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath 2^>nul`
    ) do (
        if exist "%%i\VC\Auxiliary\Build\vcvarsall.bat" (
            set "VCVARS=%%i\VC\Auxiliary\Build\vcvarsall.bat"
        )
    )
)

:: ---------------------------------------------------------------
:: Manual fallback - check each path individually (spaces-safe)
:: ---------------------------------------------------------------
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"      set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"    set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"      set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"      set "VCVARS=%ProgramFiles%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"     set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"   set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"    set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"    set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat"     set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Community\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvarsall.bat"   set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Professional\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"    set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"    set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2019\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2017\Community\VC\Auxiliary\Build\vcvarsall.bat"     set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2017\Community\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2017\Professional\VC\Auxiliary\Build\vcvarsall.bat"   set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2017\Professional\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2017\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"    set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2017\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
if not defined VCVARS if exist "%ProgramFiles(x86)%\Microsoft Visual Studio\2017\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"    set "VCVARS=%ProgramFiles(x86)%\Microsoft Visual Studio\2017\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"

if not defined VCVARS (
    echo [ERROR] Could not find vcvarsall.bat.
    echo.
    echo Install Visual Studio 2017 / 2019 / 2022 ^(any edition^) or
    echo "Build Tools for Visual Studio" with the
    echo "Desktop development with C++" workload checked.
    echo.
    echo Download: https://visualstudio.microsoft.com/downloads/
    echo ^(scroll to "Tools for Visual Studio" ^> "Build Tools for Visual Studio"^)
    echo.
    goto :FAIL
)

echo [OK] Found MSVC at:
echo      %VCVARS%
echo.

:: ---------------------------------------------------------------
:: Step 2: set up x64 environment
:: ---------------------------------------------------------------
call "%VCVARS%" x64
if errorlevel 1 (
    echo [ERROR] vcvarsall.bat x64 failed - MSVC environment not initialised.
    goto :FAIL
)
echo.
echo [OK] MSVC x64 environment ready.
echo.

:: ---------------------------------------------------------------
:: Step 3: cd to script directory
:: ---------------------------------------------------------------
cd /d "%~dp0"
if not exist "JewlessLauncher.c" (
    echo [ERROR] JewlessLauncher.c not found in %~dp0
    echo Put BUILD_LAUNCHER.bat in the same folder as JewlessLauncher.c and retry.
    goto :FAIL
)

:: ---------------------------------------------------------------
:: Step 4: back up any existing JewlessLauncher.exe before overwriting
:: ---------------------------------------------------------------
if exist "JewlessLauncher.exe" (
    set "BACKUP_EXE=JewlessLauncher.exe.bak_%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2%_%TIME:~0,2%-%TIME:~3,2%-%TIME:~6,2%"
    set "BACKUP_EXE=!BACKUP_EXE: =0!"
    copy /y "JewlessLauncher.exe" "!BACKUP_EXE!" >nul
    echo [INFO] Existing JewlessLauncher.exe backed up as:
    echo        !BACKUP_EXE!
    echo.
)

:: ---------------------------------------------------------------
:: Step 5: also back up any existing .obj from previous attempts
:: (cl.exe leaves these around; we don't delete, just rename)
:: ---------------------------------------------------------------
if exist "JewlessLauncher.obj" (
    set "BACKUP_OBJ=JewlessLauncher.obj.bak_%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2%_%TIME:~0,2%-%TIME:~3,2%-%TIME:~6,2%"
    set "BACKUP_OBJ=!BACKUP_OBJ: =0!"
    copy /y "JewlessLauncher.obj" "!BACKUP_OBJ!" >nul
    echo [INFO] Existing JewlessLauncher.obj backed up as:
    echo        !BACKUP_OBJ!
    echo.
)

:: ---------------------------------------------------------------
:: Step 6: compile JewlessLauncher.exe
:: ---------------------------------------------------------------
echo [BUILD] Compiling JewlessLauncher.c ...
echo.

cl /O2 /W3 /nologo JewlessLauncher.c ^
    /link /SUBSYSTEM:WINDOWS /OUT:JewlessLauncher.exe ^
    user32.lib gdi32.lib

set "CL_EXIT=%ERRORLEVEL%"

:: ---------------------------------------------------------------
:: Step 7: verify JewlessLauncher.exe
:: ---------------------------------------------------------------
echo.
if %CL_EXIT% neq 0 (
    echo [ERROR] cl.exe returned exit code %CL_EXIT% building JewlessLauncher.exe.
    echo Check above for compile or linker errors.
    goto :FAIL
)

if not exist "JewlessLauncher.exe" (
    echo [ERROR] JewlessLauncher.exe was not created even though cl.exe reported success.
    echo Check above for linker errors.
    goto :FAIL
)

for %%f in ("JewlessLauncher.exe") do set "EXE_SIZE=%%~zf"
echo [OK] JewlessLauncher.exe built - %EXE_SIZE% bytes
echo.

:: ---------------------------------------------------------------
:: All done
:: ---------------------------------------------------------------
echo ============================================================
echo  LAUNCHER BUILD SUCCEEDED
echo  JewlessLauncher.exe: %~dp0JewlessLauncher.exe  (%EXE_SIZE% bytes)
echo ============================================================
echo.
echo CONFIGURE BEFORE FIRST RUN (edit JewlessLauncher.c, then rebuild):
echo   SERVER_IP   - your server's IP or domain
echo   SERVER_PORT - default 30120
echo   CLIENT_EXE  - path to the client exe the launcher should start
echo.
echo TO RUN:
echo   Double-click JewlessLauncher.exe - click CONNECT.
echo.
goto :END

:FAIL
echo.
echo ============================================================
echo  BUILD FAILED - see errors above.
echo ============================================================
echo.
pause
exit /b 1

:END
endlocal
pause
exit /b 0
