@echo off
setlocal EnableDelayedExpansion

:: ============================================================
::  BUILD_LAUNCHER_v3.bat
::  Builds JewlessLauncher_v3_20260518.c  ->  JewlessLauncher.exe
::
::  Changes vs BUILD_LAUNCHER_v2:
::    - links comdlg32.lib  (GetOpenFileNameW - file browse)
::    - links comctl32.lib  (InitCommonControlsEx - dialog widgets)
::
::  Hook DLL is built separately with BUILD.bat or your existing
::  hook build script.  Drop JewlessHook.dll next to the launcher
::  exe (or set hook_dll path in jewless_config.ini / Settings).
::
::  Requires: Visual Studio (any edition) with MSVC toolchain.
:: ============================================================

:: ---------- locate vswhere ----------
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" (
    set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"
)
if not exist "%VSWHERE%" (
    echo [ERROR] vswhere.exe not found. Install Visual Studio with C++ workload.
    pause
    exit /b 1
)

:: ---------- find latest VS install ----------
for /f "usebackq tokens=*" %%i in (
    `"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`
) do set "VS_PATH=%%i"

if not defined VS_PATH (
    echo [ERROR] No Visual Studio installation with MSVC found.
    pause
    exit /b 1
)

set "VCVARS=%VS_PATH%\VC\Auxiliary\Build\vcvarsall.bat"
if not exist "%VCVARS%" (
    echo [ERROR] vcvarsall.bat not found at: %VCVARS%
    pause
    exit /b 1
)

:: ---------- set up x64 toolchain ----------
echo [INFO] Initialising MSVC x64 environment...
call "%VCVARS%" x64 >nul 2>&1

:: ---------- compile ----------
echo [INFO] Compiling JewlessLauncher_v3_20260518.c ...

cl /O2 /W3 /nologo ^
    JewlessLauncher_v3_20260518.c ^
    /link /SUBSYSTEM:WINDOWS ^
    /OUT:JewlessLauncher.exe ^
    user32.lib gdi32.lib comdlg32.lib winhttp.lib comctl32.lib

if %ERRORLEVEL% neq 0 (
    echo.
    echo [FAIL] Build failed -- see errors above.
    pause
    exit /b %ERRORLEVEL%
)

echo.
echo [OK] JewlessLauncher.exe built successfully.
echo.
echo Reminder: hook is deployed at launch time to:
echo    ^<client_exe_dir^>\version.dll
echo If a version.dll already exists there, it gets backed up
echo as version.dll.jewless-backup on first deploy.
pause
