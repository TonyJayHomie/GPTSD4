/*  JewlessLauncher_v3_20260518.c
 *  JEWLESS SOCIETY  -  Private Server Launcher  (Phase 1, revision 3)
 *
 *  Changes from v2 (the one that left out hook deployment):
 *    - Hook DLL is now deployed to the target client's directory as
 *      version.dll BEFORE CreateProcessW, so the hook is loaded into
 *      the client's address space and intercepts WinHttp from frame 0.
 *      (DLL search-order proxy. Original version.dll, if any, is
 *      backed up to version.dll.jewless-backup on first deploy.)
 *    - CreateProcessW now uses target_exe's directory as cwd, not the
 *      launcher's directory. Fixes the "client can't find its rpf/dll"
 *      bug when launching from anywhere other than the client dir.
 *    - Editable settings: Settings dialog exposes server IP, server
 *      port, client exe path, and hook DLL path. Saved back to
 *      jewless_config.ini on OK. Editable on the fly if files move.
 *    - Dev launch button: bypasses host/port validation for offline
 *      testing of the launcher loop, BUT still deploys the hook
 *      (unlike v2.1 which omitted the hook step entirely).
 *    - All errors reported via the status row (SetStatusBar), no
 *      MessageBox popups.
 *
 *  Build (MSVC x64 dev cmd prompt):
 *    cl /O2 /W3 /nologo JewlessLauncher_v3_20260518.c ^
 *       /link /SUBSYSTEM:WINDOWS /OUT:JewlessLauncher.exe ^
 *       user32.lib gdi32.lib comdlg32.lib winhttp.lib comctl32.lib
 *
 *  Build (MinGW-w64):
 *    x86_64-w64-mingw32-gcc -O2 -municode -mwindows ^
 *       JewlessLauncher_v3_20260518.c ^
 *       -o JewlessLauncher.exe ^
 *       -luser32 -lgdi32 -lcomdlg32 -lwinhttp -lcomctl32
 */

#define WIN32_LEAN_AND_MEAN
#define UNICODE
#define _UNICODE
#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <winhttp.h>
#include <commdlg.h>
#include <commctrl.h>
#include <wchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "comdlg32.lib")
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "comctl32.lib")

/* ------------------------------------------------------------------ */
/*   Window dimensions                                                */
/* ------------------------------------------------------------------ */
#define WND_W     580
#define WND_H     440
#define TOP_BAR     4

/* Palette */
#define CLR_BG       RGB( 10,  10,  10)
#define CLR_BG2      RGB( 22,  22,  22)
#define CLR_GOLD     RGB(212, 175,  55)
#define CLR_AMBER    RGB(245, 165,  35)
#define CLR_WHITE    RGB(255, 255, 255)
#define CLR_GREY     RGB(140, 140, 140)
#define CLR_GREYDK   RGB( 60,  60,  60)
#define CLR_GREEN    RGB( 80, 200,  80)
#define CLR_RED      RGB(220,  60,  60)

/* Custom messages */
#define WM_POLL_DONE   (WM_USER + 1)
#define WM_HOOK_STATUS (WM_USER + 2)

/* Layout (window-relative pixel Y positions) */
#define Y_LOGO         28
#define Y_TAGLINE      78
#define Y_STATUS      136
#define Y_DIVIDER     164
#define Y_BTN_CONNECT 190
#define Y_BTN_DEV     250
#define Y_BTN_SET     295
#define Y_STATUSBAR   355
#define Y_BOTTOMBAR   410

/* Control IDs */
#define ID_BTN_CONNECT  101
#define ID_BTN_DEV      102
#define ID_BTN_SETTINGS 103

/* Settings dialog IDs */
#define IDD_SETTINGS     200
#define IDC_ED_IP        201
#define IDC_ED_PORT      202
#define IDC_ED_CLIENT    203
#define IDC_BTN_BR_CLI   204
#define IDC_ED_HOOK      205
#define IDC_BTN_BR_HOOK  206
#define IDC_LBL_IP       210
#define IDC_LBL_PORT     211
#define IDC_LBL_CLI      212
#define IDC_LBL_HOOK     213
#define IDC_LBL_HINT     214

/* ------------------------------------------------------------------ */
/*   Config globals (populated by LoadConfig)                         */
/* ------------------------------------------------------------------ */
static char    g_cfgIp[128]              = "127.0.0.1";
static char    g_cfgPort[16]             = "30120";
static wchar_t g_cfgClientExe[MAX_PATH]  = L".\\client\\FXClient.exe";
static wchar_t g_cfgHookDll[MAX_PATH]    = L".\\JewlessHook.dll";

/* Path to launcher's own directory (with trailing backslash), filled in main */
static wchar_t g_launcherDir[MAX_PATH] = {0};
/* Full path to the ini file */
static wchar_t g_iniPath[MAX_PATH] = {0};

/* ------------------------------------------------------------------ */
/*   Server-status shared state                                       */
/* ------------------------------------------------------------------ */
typedef struct {
    BOOL    checked;
    BOOL    online;
    int     clients;
    int     maxClients;
    wchar_t hostname[256];
} SrvStatus;

static SrvStatus        g_srv;
static CRITICAL_SECTION g_srvLock;

static HANDLE g_stopEvent  = NULL;
static HANDLE g_pollThread = NULL;
static HWND   g_hwnd       = NULL;
static HWND   g_hStatusBar = NULL;  /* status row at bottom (text-only label) */

/* Status bar text (set under g_srvLock, painted in WM_PAINT) */
static wchar_t g_statusBarText[512] = L"Ready.";
static COLORREF g_statusBarCol = RGB(180,180,180);

/* ------------------------------------------------------------------ */
/*   Forward decls                                                    */
/* ------------------------------------------------------------------ */
static void SetStatusBar(const wchar_t *msg, COLORREF col);

/* ------------------------------------------------------------------ */
/*   String helpers                                                   */
/* ------------------------------------------------------------------ */
static void TrimRight(char *s)
{
    size_t n = strlen(s);
    while (n > 0 && (s[n-1] == ' '  || s[n-1] == '\t' ||
                     s[n-1] == '\r' || s[n-1] == '\n'))
        s[--n] = '\0';
}

static void TrimRightW(wchar_t *s)
{
    size_t n = wcslen(s);
    while (n > 0 && (s[n-1] == L' '  || s[n-1] == L'\t' ||
                     s[n-1] == L'\r' || s[n-1] == L'\n'))
        s[--n] = L'\0';
}

/* ------------------------------------------------------------------ */
/*   LoadConfig / SaveConfig                                          */
/*                                                                    */
/*   ini format: simple "key = value" lines, '#' or ';' for comments. */
/*   Unknown keys ignored. Missing file -> defaults used silently.    */
/* ------------------------------------------------------------------ */
static void LoadConfig(void)
{
    FILE *fp = NULL;
    if (_wfopen_s(&fp, g_iniPath, L"r") != 0 || !fp) return;

    char line[1024];
    while (fgets(line, sizeof(line), fp))
    {
        char *p = line;
        while (*p == ' ' || *p == '\t') ++p;
        if (*p == '#' || *p == ';' || *p == '\0' ||
            *p == '\r' || *p == '\n') continue;

        char *eq = strchr(p, '=');
        if (!eq) continue;

        char key[64] = {0};
        int  klen   = (int)(eq - p);
        if (klen <= 0 || klen >= (int)sizeof(key)) continue;
        strncpy_s(key, sizeof(key), p, klen);
        TrimRight(key);

        char *kp = key;
        while (*kp == ' ' || *kp == '\t') ++kp;

        char val[700] = {0};
        strncpy_s(val, sizeof(val), eq + 1, _TRUNCATE);
        char *vp = val;
        while (*vp == ' ' || *vp == '\t') ++vp;
        TrimRight(vp);

        if (_stricmp(kp, "server_ip") == 0)
            strncpy_s(g_cfgIp, sizeof(g_cfgIp), vp, _TRUNCATE);
        else if (_stricmp(kp, "server_port") == 0)
            strncpy_s(g_cfgPort, sizeof(g_cfgPort), vp, _TRUNCATE);
        else if (_stricmp(kp, "client_exe") == 0)
            MultiByteToWideChar(CP_UTF8, 0, vp, -1, g_cfgClientExe, MAX_PATH);
        else if (_stricmp(kp, "hook_dll") == 0)
            MultiByteToWideChar(CP_UTF8, 0, vp, -1, g_cfgHookDll, MAX_PATH);
    }
    fclose(fp);

    /* Sanitize placeholder values that come from the shipped template */
    if (_stricmp(g_cfgIp, "YOUR.SERVER.IP.HERE") == 0)
        strcpy_s(g_cfgIp, sizeof(g_cfgIp), "127.0.0.1");
}

static void SaveConfig(void)
{
    FILE *fp = NULL;
    if (_wfopen_s(&fp, g_iniPath, L"w") != 0 || !fp) return;

    char clientUtf8[MAX_PATH*3] = {0};
    char hookUtf8  [MAX_PATH*3] = {0};
    WideCharToMultiByte(CP_UTF8, 0, g_cfgClientExe, -1, clientUtf8, sizeof(clientUtf8), NULL, NULL);
    WideCharToMultiByte(CP_UTF8, 0, g_cfgHookDll,   -1, hookUtf8,   sizeof(hookUtf8),   NULL, NULL);

    fprintf(fp,
        "# ============================================================\n"
        "#  Jewless Launcher - Configuration File\n"
        "#  jewless_config.ini  (place next to JewlessLauncher.exe)\n"
        "#\n"
        "#  server_ip   - IP/hostname of your FXServer\n"
        "#  server_port - port (default 30120)\n"
        "#  client_exe  - path to your CitizenFX client binary\n"
        "#  hook_dll    - path to JewlessHook.dll (the version.dll proxy)\n"
        "#                Relative paths resolve from this file's folder.\n"
        "# ============================================================\n"
        "\n"
        "server_ip   = %s\n"
        "server_port = %s\n"
        "client_exe  = %s\n"
        "hook_dll    = %s\n",
        g_cfgIp, g_cfgPort, clientUtf8, hookUtf8);
    fclose(fp);
}

/* ------------------------------------------------------------------ */
/*   Path helpers                                                     */
/* ------------------------------------------------------------------ */

/* Resolve a possibly-relative wide path against g_launcherDir. */
static void ResolveAgainstLauncher(const wchar_t *in, wchar_t *out, size_t outChars)
{
    /* absolute already if drive-letter or UNC */
    if ((iswalpha(in[0]) && in[1] == L':') ||
        (in[0] == L'\\' && in[1] == L'\\'))
    {
        wcsncpy_s(out, outChars, in, _TRUNCATE);
        return;
    }
    _snwprintf_s(out, outChars, _TRUNCATE, L"%s%s", g_launcherDir, in);
}

/* Strip filename component, leave trailing backslash. */
static void DirOfPath(const wchar_t *path, wchar_t *out, size_t outChars)
{
    wcsncpy_s(out, outChars, path, _TRUNCATE);
    wchar_t *last = wcsrchr(out, L'\\');
    if (!last) last = wcsrchr(out, L'/');
    if (last) *(last + 1) = L'\0';
    else out[0] = L'\0';
}

/* ------------------------------------------------------------------ */
/*   Minimal JSON field reader  (good enough for /dynamic.json)       */
/* ------------------------------------------------------------------ */
static BOOL JsonGet(const char *src, const char *key, char *out, int outLen)
{
    char pat[128];
    _snprintf_s(pat, sizeof(pat), _TRUNCATE, "\"%s\":", key);

    const char *p = strstr(src, pat);
    if (!p) return FALSE;
    p += strlen(pat);

    while (*p == ' ' || *p == '\t') ++p;

    if (*p == '"')
    {
        ++p;
        int i = 0;
        while (*p && *p != '"' && i < outLen - 1)
            out[i++] = *p++;
        out[i] = '\0';
    }
    else
    {
        int i = 0;
        while (*p && *p != ',' && *p != '}' &&
               *p != '\r' && *p != '\n' && i < outLen - 1)
            out[i++] = *p++;
        out[i] = '\0';
        TrimRight(out);
    }
    return TRUE;
}

/* ------------------------------------------------------------------ */
/*   Synchronous HTTP GET via WinHttp                                 */
/* ------------------------------------------------------------------ */
static char *HttpGet(const wchar_t *host, INTERNET_PORT port, const wchar_t *path)
{
    char      *body     = NULL;
    HINTERNET  hSession = NULL, hConnect = NULL, hRequest = NULL;

    hSession = WinHttpOpen(L"JewlessLauncher/3.0",
                           WINHTTP_ACCESS_TYPE_DEFAULT_PROXY,
                           WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) goto done;

    DWORD tout = 5000;
    WinHttpSetOption(hSession, WINHTTP_OPTION_CONNECT_TIMEOUT, &tout, sizeof(tout));
    WinHttpSetOption(hSession, WINHTTP_OPTION_SEND_TIMEOUT,    &tout, sizeof(tout));
    WinHttpSetOption(hSession, WINHTTP_OPTION_RECEIVE_TIMEOUT, &tout, sizeof(tout));

    hConnect = WinHttpConnect(hSession, host, port, 0);
    if (!hConnect) goto done;

    hRequest = WinHttpOpenRequest(hConnect, L"GET", path, NULL,
                                  WINHTTP_NO_REFERER,
                                  WINHTTP_DEFAULT_ACCEPT_TYPES, 0);
    if (!hRequest) goto done;

    if (!WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0,
                            WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) goto done;
    if (!WinHttpReceiveResponse(hRequest, NULL)) goto done;

    size_t total = 0, cap = 4096;
    body = (char *)malloc(cap);
    if (!body) goto done;

    DWORD avail = 0, nread = 0;
    while (WinHttpQueryDataAvailable(hRequest, &avail) && avail > 0)
    {
        if (total + avail + 1 > cap)
        {
            cap = total + avail + 1024;
            char *tmp = (char *)realloc(body, cap);
            if (!tmp) { free(body); body = NULL; goto done; }
            body = tmp;
        }
        if (!WinHttpReadData(hRequest, body + total, avail, &nread)) break;
        total += nread;
    }
    if (body) body[total] = '\0';

done:
    if (hRequest) WinHttpCloseHandle(hRequest);
    if (hConnect) WinHttpCloseHandle(hConnect);
    if (hSession) WinHttpCloseHandle(hSession);
    return body;
}

/* ------------------------------------------------------------------ */
/*   Polling                                                          */
/* ------------------------------------------------------------------ */
static void DoPoll(void)
{
    wchar_t wHost[128] = {0};
    MultiByteToWideChar(CP_ACP, 0, g_cfgIp, -1, wHost, 128);
    INTERNET_PORT port = (INTERNET_PORT)(WORD)atoi(g_cfgPort);

    char *json = HttpGet(wHost, port, L"/dynamic.json");

    EnterCriticalSection(&g_srvLock);
    g_srv.checked = TRUE;

    if (!json)
    {
        g_srv.online      = FALSE;
        g_srv.clients     = 0;
        g_srv.maxClients  = 0;
        g_srv.hostname[0] = L'\0';
    }
    else
    {
        g_srv.online = TRUE;
        char tmp[64];

        if (JsonGet(json, "clients", tmp, sizeof(tmp)))
            g_srv.clients = atoi(tmp);
        else
            g_srv.clients = 0;

        if (JsonGet(json, "sv_maxclients", tmp, sizeof(tmp)))
            g_srv.maxClients = atoi(tmp);
        else
            g_srv.maxClients = 0;

        char hn[256] = {0};
        if (JsonGet(json, "hostname", hn, sizeof(hn)))
            MultiByteToWideChar(CP_UTF8, 0, hn, -1, g_srv.hostname, 256);
        else
            g_srv.hostname[0] = L'\0';

        free(json);
    }
    LeaveCriticalSection(&g_srvLock);
}

static DWORD WINAPI PollThread(LPVOID unused)
{
    (void)unused;
    DoPoll();
    if (g_hwnd) PostMessage(g_hwnd, WM_POLL_DONE, 0, 0);

    while (WaitForSingleObject(g_stopEvent, 10000) == WAIT_TIMEOUT)
    {
        DoPoll();
        if (g_hwnd) PostMessage(g_hwnd, WM_POLL_DONE, 0, 0);
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/*   Hook deployment                                                  */
/*                                                                    */
/*   The hook is a version.dll proxy. To get loaded into the target   */
/*   client's address space, it must be named version.dll and sit in  */
/*   the same directory as the target exe (Windows DLL search order   */
/*   resolves version.dll from the exe's dir before %WINDIR%).        */
/*                                                                    */
/*   Strategy:                                                        */
/*     - Resolve hook DLL source path (config: hook_dll)               */
/*     - If <target_dir>\version.dll already exists AND                */
/*       <target_dir>\version.dll.jewless-backup does NOT exist:       */
/*         move existing version.dll to backup (preserves true         */
/*         original from first deploy, never overwrites it on          */
/*         subsequent re-deploys).                                    */
/*     - Copy hook DLL to <target_dir>\version.dll (overwrite).        */
/* ------------------------------------------------------------------ */
static BOOL FileExistsW(const wchar_t *path)
{
    DWORD a = GetFileAttributesW(path);
    return (a != INVALID_FILE_ATTRIBUTES) && !(a & FILE_ATTRIBUTE_DIRECTORY);
}

/* Returns TRUE on success. On failure, errBuf gets a human-readable reason. */
static BOOL DeployHook(const wchar_t *targetDir,
                       wchar_t *errBuf, size_t errChars)
{
    /* Resolve hook source */
    wchar_t hookSrc[MAX_PATH] = {0};
    ResolveAgainstLauncher(g_cfgHookDll, hookSrc, MAX_PATH);

    if (!FileExistsW(hookSrc))
    {
        _snwprintf_s(errBuf, errChars, _TRUNCATE,
            L"Hook DLL not found at: %s", hookSrc);
        return FALSE;
    }

    /* Build dest paths */
    wchar_t destDll[MAX_PATH] = {0};
    wchar_t backupDll[MAX_PATH] = {0};
    _snwprintf_s(destDll,   MAX_PATH, _TRUNCATE, L"%sversion.dll", targetDir);
    _snwprintf_s(backupDll, MAX_PATH, _TRUNCATE, L"%sversion.dll.jewless-backup", targetDir);

    /* If a version.dll exists and we have no backup yet, back it up. */
    if (FileExistsW(destDll) && !FileExistsW(backupDll))
    {
        if (!MoveFileExW(destDll, backupDll, MOVEFILE_COPY_ALLOWED))
        {
            DWORD err = GetLastError();
            _snwprintf_s(errBuf, errChars, _TRUNCATE,
                L"Failed to back up existing version.dll (err %lu): %s",
                err, destDll);
            return FALSE;
        }
    }

    /* Copy hook into place (overwrite) */
    if (!CopyFileW(hookSrc, destDll, FALSE))
    {
        DWORD err = GetLastError();
        _snwprintf_s(errBuf, errChars, _TRUNCATE,
            L"Failed to copy hook to %s (err %lu)", destDll, err);
        return FALSE;
    }

    errBuf[0] = L'\0';
    return TRUE;
}

/* Optional inverse, currently unused but here for parity / future button. */
static BOOL RestoreOriginalDll(const wchar_t *targetDir,
                               wchar_t *errBuf, size_t errChars)
{
    wchar_t destDll[MAX_PATH] = {0};
    wchar_t backupDll[MAX_PATH] = {0};
    _snwprintf_s(destDll,   MAX_PATH, _TRUNCATE, L"%sversion.dll", targetDir);
    _snwprintf_s(backupDll, MAX_PATH, _TRUNCATE, L"%sversion.dll.jewless-backup", targetDir);

    if (FileExistsW(destDll))
    {
        if (!DeleteFileW(destDll))
        {
            _snwprintf_s(errBuf, errChars, _TRUNCATE,
                L"Could not delete current version.dll (err %lu)",
                GetLastError());
            return FALSE;
        }
    }

    if (FileExistsW(backupDll))
    {
        if (!MoveFileExW(backupDll, destDll, MOVEFILE_COPY_ALLOWED))
        {
            _snwprintf_s(errBuf, errChars, _TRUNCATE,
                L"Could not restore backup (err %lu)", GetLastError());
            return FALSE;
        }
    }
    errBuf[0] = L'\0';
    return TRUE;
}

/* ------------------------------------------------------------------ */
/*   Launching                                                        */
/* ------------------------------------------------------------------ */

/* Common backend: resolves paths, deploys hook, runs CreateProcessW. */
/* Returns TRUE on launch success. msg ends up in status bar.         */
static BOOL LaunchWithHook(BOOL validateHost)
{
    /* ---------- 1. Validate config ---------- */
    if (validateHost)
    {
        if (g_cfgIp[0] == '\0')
        {
            SetStatusBar(L"Server IP is empty (open Settings to set it).", CLR_RED);
            return FALSE;
        }
        int portNum = atoi(g_cfgPort);
        if (portNum <= 0 || portNum > 65535)
        {
            SetStatusBar(L"Invalid server port.", CLR_RED);
            return FALSE;
        }
    }

    if (g_cfgClientExe[0] == L'\0')
    {
        SetStatusBar(L"Client EXE path is empty (open Settings).", CLR_RED);
        return FALSE;
    }

    /* ---------- 2. Resolve client exe + its directory ---------- */
    wchar_t clientFull[MAX_PATH] = {0};
    ResolveAgainstLauncher(g_cfgClientExe, clientFull, MAX_PATH);

    if (!FileExistsW(clientFull))
    {
        wchar_t buf[600];
        _snwprintf_s(buf, 600, _TRUNCATE,
            L"Client exe not found: %s", clientFull);
        SetStatusBar(buf, CLR_RED);
        return FALSE;
    }

    wchar_t clientDir[MAX_PATH] = {0};
    DirOfPath(clientFull, clientDir, MAX_PATH);
    if (clientDir[0] == L'\0')
    {
        SetStatusBar(L"Could not determine client directory.", CLR_RED);
        return FALSE;
    }

    /* ---------- 3. Deploy hook ---------- */
    SetStatusBar(L"Deploying hook...", CLR_GREY);
    {
        wchar_t err[600] = {0};
        if (!DeployHook(clientDir, err, 600))
        {
            SetStatusBar(err, CLR_RED);
            return FALSE;
        }
    }

    /* ---------- 4. Build command line + cwd, launch ---------- */
    wchar_t cmdLine[1024];
    if (validateHost)
    {
        _snwprintf_s(cmdLine, 1024, _TRUNCATE,
            L"\"%s\" +connect %hs:%hs",
            clientFull, g_cfgIp, g_cfgPort);
    }
    else
    {
        /* Dev launch: still uses configured host/port if present, but
         * doesn't refuse to launch if they're blank/sketchy. The point
         * is to exercise the hook + launch loop offline. */
        if (g_cfgIp[0] != '\0')
        {
            _snwprintf_s(cmdLine, 1024, _TRUNCATE,
                L"\"%s\" +connect %hs:%hs",
                clientFull, g_cfgIp, g_cfgPort);
        }
        else
        {
            _snwprintf_s(cmdLine, 1024, _TRUNCATE,
                L"\"%s\"", clientFull);
        }
    }

    STARTUPINFOW        si = { sizeof(si) };
    PROCESS_INFORMATION pi = {0};

    /* cwd = client's own directory (not the launcher's) so client can
     * resolve its rpf/dll/asset files. This was the v2.1 working-dir bug. */
    BOOL ok = CreateProcessW(NULL, cmdLine, NULL, NULL, FALSE,
                             DETACHED_PROCESS, NULL, clientDir, &si, &pi);
    if (!ok)
    {
        DWORD err = GetLastError();
        wchar_t buf[300];
        _snwprintf_s(buf, 300, _TRUNCATE,
            L"CreateProcess failed (err %lu).", err);
        SetStatusBar(buf, CLR_RED);
        return FALSE;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);

    SetStatusBar(validateHost
        ? L"Client launched with hook. Connecting..."
        : L"Dev launch: hook deployed, client started.", CLR_GREEN);
    return TRUE;
}

static void DoConnect(HWND hwnd)
{
    (void)hwnd;
    LaunchWithHook(TRUE);
}

static void DoDevLaunch(HWND hwnd)
{
    (void)hwnd;
    LaunchWithHook(FALSE);
}

/* ------------------------------------------------------------------ */
/*   Status-bar helper                                                */
/* ------------------------------------------------------------------ */
static void SetStatusBar(const wchar_t *msg, COLORREF col)
{
    wcsncpy_s(g_statusBarText, 512, msg, _TRUNCATE);
    g_statusBarCol = col;
    if (g_hwnd)
    {
        RECT r;
        r.left = 0; r.right = WND_W;
        r.top = Y_STATUSBAR - 2; r.bottom = Y_STATUSBAR + 22;
        InvalidateRect(g_hwnd, &r, FALSE);
    }
}

/* ------------------------------------------------------------------ */
/*   File-browse helper                                               */
/* ------------------------------------------------------------------ */
static BOOL BrowseForFile(HWND owner, const wchar_t *title,
                          const wchar_t *filter,
                          wchar_t *out, int outChars)
{
    OPENFILENAMEW ofn = { sizeof(ofn) };
    ofn.hwndOwner    = owner;
    ofn.lpstrFile    = out;
    ofn.nMaxFile     = outChars;
    ofn.lpstrFilter  = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrTitle   = title;
    ofn.Flags        = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR;
    return GetOpenFileNameW(&ofn);
}

/* ------------------------------------------------------------------ */
/*   Settings dialog                                                  */
/*                                                                    */
/*   Built in-code (no .rc) so this stays a single-source file.       */
/* ------------------------------------------------------------------ */
static INT_PTR CALLBACK SettingsDlgProc(HWND hDlg, UINT msg,
                                        WPARAM wParam, LPARAM lParam)
{
    (void)lParam;
    switch (msg)
    {
    case WM_INITDIALOG:
    {
        /* Populate fields from current config */
        wchar_t wIp[128] = {0};
        MultiByteToWideChar(CP_UTF8, 0, g_cfgIp,   -1, wIp,   128);
        wchar_t wPort[16] = {0};
        MultiByteToWideChar(CP_UTF8, 0, g_cfgPort, -1, wPort, 16);

        SetDlgItemTextW(hDlg, IDC_ED_IP,     wIp);
        SetDlgItemTextW(hDlg, IDC_ED_PORT,   wPort);
        SetDlgItemTextW(hDlg, IDC_ED_CLIENT, g_cfgClientExe);
        SetDlgItemTextW(hDlg, IDC_ED_HOOK,   g_cfgHookDll);
        return TRUE;
    }

    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case IDC_BTN_BR_CLI:
        {
            wchar_t buf[MAX_PATH] = {0};
            GetDlgItemTextW(hDlg, IDC_ED_CLIENT, buf, MAX_PATH);
            if (BrowseForFile(hDlg,
                    L"Select your CitizenFX client (FXClient.exe / FiveM.exe)",
                    L"Executables (*.exe)\0*.exe\0All Files (*.*)\0*.*\0",
                    buf, MAX_PATH))
                SetDlgItemTextW(hDlg, IDC_ED_CLIENT, buf);
            return TRUE;
        }
        case IDC_BTN_BR_HOOK:
        {
            wchar_t buf[MAX_PATH] = {0};
            GetDlgItemTextW(hDlg, IDC_ED_HOOK, buf, MAX_PATH);
            if (BrowseForFile(hDlg,
                    L"Select JewlessHook.dll",
                    L"DLL Files (*.dll)\0*.dll\0All Files (*.*)\0*.*\0",
                    buf, MAX_PATH))
                SetDlgItemTextW(hDlg, IDC_ED_HOOK, buf);
            return TRUE;
        }

        case IDOK:
        {
            wchar_t wIp[128]   = {0};
            wchar_t wPort[16]  = {0};
            wchar_t wCli[MAX_PATH] = {0};
            wchar_t wHook[MAX_PATH] = {0};

            GetDlgItemTextW(hDlg, IDC_ED_IP,     wIp,   128);
            GetDlgItemTextW(hDlg, IDC_ED_PORT,   wPort, 16);
            GetDlgItemTextW(hDlg, IDC_ED_CLIENT, wCli,  MAX_PATH);
            GetDlgItemTextW(hDlg, IDC_ED_HOOK,   wHook, MAX_PATH);

            TrimRightW(wIp); TrimRightW(wPort);
            TrimRightW(wCli); TrimRightW(wHook);

            WideCharToMultiByte(CP_UTF8, 0, wIp,   -1, g_cfgIp,   sizeof(g_cfgIp),   NULL, NULL);
            WideCharToMultiByte(CP_UTF8, 0, wPort, -1, g_cfgPort, sizeof(g_cfgPort), NULL, NULL);
            wcsncpy_s(g_cfgClientExe, MAX_PATH, wCli,  _TRUNCATE);
            wcsncpy_s(g_cfgHookDll,   MAX_PATH, wHook, _TRUNCATE);

            SaveConfig();
            SetStatusBar(L"Settings saved.", CLR_GREEN);
            InvalidateRect(g_hwnd, NULL, FALSE);  /* repaint with new IP:port */
            EndDialog(hDlg, IDOK);
            return TRUE;
        }
        case IDCANCEL:
            EndDialog(hDlg, IDCANCEL);
            return TRUE;
        }
        break;

    case WM_CLOSE:
        EndDialog(hDlg, IDCANCEL);
        return TRUE;
    }
    return FALSE;
}

/* Build the in-memory DLGTEMPLATE for the settings dialog.            */
/* Returns malloc'd buffer the caller must free. NULL on OOM.          */
static LPDLGTEMPLATEW BuildSettingsDlgTemplate(void)
{
    /* Compute generous upper bound */
    size_t cap = 4096;
    BYTE *buf = (BYTE *)calloc(1, cap);
    if (!buf) return NULL;
    BYTE *p = buf;

    /* DLGTEMPLATE */
    DLGTEMPLATE *t = (DLGTEMPLATE *)p;
    t->style           = DS_MODALFRAME | DS_CENTER | DS_SETFONT |
                         WS_POPUP | WS_VISIBLE | WS_CAPTION | WS_SYSMENU;
    t->dwExtendedStyle = 0;
    t->cdit            = 13;    /* number of controls below */
    t->x  = 0;  t->y  = 0;
    t->cx = 280; t->cy = 200;
    p += sizeof(DLGTEMPLATE);

    /* menu (none) */ *(WORD *)p = 0; p += sizeof(WORD);
    /* class (default) */ *(WORD *)p = 0; p += sizeof(WORD);
    /* title */ {
        const wchar_t *title = L"Jewless Launcher - Settings";
        size_t n = wcslen(title) + 1;
        memcpy(p, title, n * sizeof(wchar_t));
        p += n * sizeof(wchar_t);
    }
    /* font (DS_SETFONT): pointsize + face */
    *(WORD *)p = 9; p += sizeof(WORD);
    {
        const wchar_t *face = L"Segoe UI";
        size_t n = wcslen(face) + 1;
        memcpy(p, face, n * sizeof(wchar_t));
        p += n * sizeof(wchar_t);
    }

    /* helper to align p to DWORD boundary */
    #define ALIGN_DW() do { uintptr_t a = (uintptr_t)p; a = (a + 3) & ~(uintptr_t)3; p = (BYTE *)a; } while(0)

    /* helper to emit one control */
    #define EMIT_CTL(_x,_y,_cx,_cy,_id,_style,_cls,_text)                  \
        do {                                                               \
            ALIGN_DW();                                                    \
            DLGITEMTEMPLATE *it = (DLGITEMTEMPLATE *)p;                    \
            it->style = (_style);                                          \
            it->dwExtendedStyle = 0;                                       \
            it->x = (_x); it->y = (_y); it->cx = (_cx); it->cy = (_cy);    \
            it->id = (_id);                                                \
            p += sizeof(DLGITEMTEMPLATE);                                  \
            *(WORD *)p = 0xFFFF; p += sizeof(WORD);                        \
            *(WORD *)p = (_cls); p += sizeof(WORD);                        \
            { const wchar_t *_t = (_text); size_t _n = wcslen(_t) + 1;     \
              memcpy(p, _t, _n * sizeof(wchar_t)); p += _n * sizeof(wchar_t); } \
            *(WORD *)p = 0; p += sizeof(WORD);                             \
        } while(0)

    /* Class atoms (Windows built-in dialog classes) */
    enum { CLS_BUTTON = 0x0080, CLS_EDIT = 0x0081, CLS_STATIC = 0x0082 };

    /* Row 1: IP */
    EMIT_CTL( 12,  10,  60, 10, IDC_LBL_IP,
             WS_CHILD|WS_VISIBLE|SS_LEFT, CLS_STATIC, L"Server IP:");
    EMIT_CTL( 80,   8, 188, 12, IDC_ED_IP,
             WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL,
             CLS_EDIT, L"");

    /* Row 2: Port */
    EMIT_CTL( 12,  30,  60, 10, IDC_LBL_PORT,
             WS_CHILD|WS_VISIBLE|SS_LEFT, CLS_STATIC, L"Server Port:");
    EMIT_CTL( 80,  28,  60, 12, IDC_ED_PORT,
             WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL|ES_NUMBER,
             CLS_EDIT, L"");

    /* Row 3: Client EXE + browse */
    EMIT_CTL( 12,  54,  60, 10, IDC_LBL_CLI,
             WS_CHILD|WS_VISIBLE|SS_LEFT, CLS_STATIC, L"Client EXE:");
    EMIT_CTL( 80,  52, 144, 12, IDC_ED_CLIENT,
             WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL,
             CLS_EDIT, L"");
    EMIT_CTL(228,  51,  40, 14, IDC_BTN_BR_CLI,
             WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,
             CLS_BUTTON, L"Browse...");

    /* Row 4: Hook DLL + browse */
    EMIT_CTL( 12,  78,  60, 10, IDC_LBL_HOOK,
             WS_CHILD|WS_VISIBLE|SS_LEFT, CLS_STATIC, L"Hook DLL:");
    EMIT_CTL( 80,  76, 144, 12, IDC_ED_HOOK,
             WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL,
             CLS_EDIT, L"");
    EMIT_CTL(228,  75,  40, 14, IDC_BTN_BR_HOOK,
             WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,
             CLS_BUTTON, L"Browse...");

    /* Hint label */
    EMIT_CTL( 12, 102, 256, 56, IDC_LBL_HINT,
             WS_CHILD|WS_VISIBLE|SS_LEFT, CLS_STATIC,
             L"Relative paths resolve against the launcher folder.\r\n"
             L"Hook DLL gets copied to <client_dir>\\version.dll on launch.\r\n"
             L"Any existing version.dll is preserved as\r\n"
             L"version.dll.jewless-backup on first deploy.");

    /* OK / Cancel */
    EMIT_CTL(150, 170,  56, 14, IDOK,
             WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_DEFPUSHBUTTON,
             CLS_BUTTON, L"OK");
    EMIT_CTL(212, 170,  56, 14, IDCANCEL,
             WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON,
             CLS_BUTTON, L"Cancel");

    #undef EMIT_CTL
    #undef ALIGN_DW

    return (LPDLGTEMPLATEW)buf;
}

static void OpenSettings(HWND parent)
{
    LPDLGTEMPLATEW tmpl = BuildSettingsDlgTemplate();
    if (!tmpl)
    {
        SetStatusBar(L"Couldn't build settings dialog.", CLR_RED);
        return;
    }
    DialogBoxIndirectW(GetModuleHandleW(NULL), tmpl, parent, SettingsDlgProc);
    free(tmpl);
}

/* ------------------------------------------------------------------ */
/*   Paint helpers                                                    */
/* ------------------------------------------------------------------ */
static void DrawCentred(HDC hdc, const wchar_t *text, int y,
                        HFONT font, COLORREF col)
{
    SelectObject(hdc, font);
    SetTextColor(hdc, col);
    SetBkMode(hdc, TRANSPARENT);

    SIZE sz;
    GetTextExtentPoint32W(hdc, text, (int)wcslen(text), &sz);
    int x = (WND_W - sz.cx) / 2;
    TextOutW(hdc, x, y, text, (int)wcslen(text));
}

/* Owner-drawn button.  bg is the fill colour when not pressed. */
static void DrawButton(DRAWITEMSTRUCT *dis, const wchar_t *label,
                       COLORREF bgNormal, COLORREF bgPressed,
                       COLORREF txtCol)
{
    BOOL pressed = (dis->itemState & ODS_SELECTED) != 0;
    BOOL focused = (dis->itemState & ODS_FOCUS)    != 0;

    HBRUSH hFill = CreateSolidBrush(pressed ? bgPressed : bgNormal);
    FillRect(dis->hDC, &dis->rcItem, hFill);
    DeleteObject(hFill);

    if (focused || pressed)
    {
        HPEN hPen    = CreatePen(PS_SOLID, 2, CLR_WHITE);
        HPEN hOldPen = (HPEN)SelectObject(dis->hDC, hPen);
        SelectObject(dis->hDC, GetStockObject(NULL_BRUSH));
        Rectangle(dis->hDC,
                  dis->rcItem.left  + 2, dis->rcItem.top    + 2,
                  dis->rcItem.right - 2, dis->rcItem.bottom - 2);
        SelectObject(dis->hDC, hOldPen);
        DeleteObject(hPen);
    }

    HFONT hFBtn = CreateFontW(
        15, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
        CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
    HFONT hOldF = (HFONT)SelectObject(dis->hDC, hFBtn);
    SetTextColor(dis->hDC, txtCol);
    SetBkMode(dis->hDC, TRANSPARENT);
    DrawTextW(dis->hDC, label, -1, &dis->rcItem,
              DT_CENTER | DT_VCENTER | DT_SINGLELINE);
    SelectObject(dis->hDC, hOldF);
    DeleteObject(hFBtn);
}

/* ------------------------------------------------------------------ */
/*   Main window procedure                                            */
/* ------------------------------------------------------------------ */
static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg,
                                 WPARAM wParam, LPARAM lParam)
{
    static HBRUSH hBrushBg    = NULL;
    static HBRUSH hBrushGold  = NULL;
    static HFONT  hFontLogo   = NULL;
    static HFONT  hFontSub    = NULL;
    static HFONT  hFontSmall  = NULL;
    static HFONT  hFontStatus = NULL;
    static HFONT  hFontTarget = NULL;

    switch (msg)
    {
    case WM_CREATE:
    {
        hBrushBg   = CreateSolidBrush(CLR_BG);
        hBrushGold = CreateSolidBrush(CLR_GOLD);

        hFontLogo = CreateFontW(46, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        hFontSub = CreateFontW(15, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        hFontSmall = CreateFontW(13, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        hFontStatus = CreateFontW(14, 0, 0, 0, FW_SEMIBOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        hFontTarget = CreateFontW(12, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Consolas");

        HINSTANCE hInst = ((LPCREATESTRUCT)lParam)->hInstance;

        /* CONNECT button (gold, primary) */
        CreateWindowExW(0, L"BUTTON", L"CONNECT TO SERVER",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            (WND_W - 240) / 2, Y_BTN_CONNECT, 240, 44,
            hwnd, (HMENU)(INT_PTR)ID_BTN_CONNECT, hInst, NULL);

        /* DEV LAUNCH button (amber, secondary) */
        CreateWindowExW(0, L"BUTTON", L"DEV LAUNCH  (no host check)",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            (WND_W - 240) / 2, Y_BTN_DEV, 240, 34,
            hwnd, (HMENU)(INT_PTR)ID_BTN_DEV, hInst, NULL);

        /* SETTINGS button (dark, tertiary) */
        CreateWindowExW(0, L"BUTTON", L"Settings...",
            WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
            (WND_W - 140) / 2, Y_BTN_SET, 140, 26,
            hwnd, (HMENU)(INT_PTR)ID_BTN_SETTINGS, hInst, NULL);

        return 0;
    }

    case WM_POLL_DONE:
        InvalidateRect(hwnd, NULL, FALSE);
        return 0;

    case WM_ERASEBKGND:
        return 1;

    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);

        /* double-buffer */
        HDC     hdcMem = CreateCompatibleDC(hdc);
        HBITMAP hBmp   = CreateCompatibleBitmap(hdc, WND_W, WND_H);
        HGDIOBJ hOld   = SelectObject(hdcMem, hBmp);

        /* background */
        RECT rcAll = {0, 0, WND_W, WND_H};
        FillRect(hdcMem, &rcAll, hBrushBg);

        /* top gold bar */
        RECT rcBar = {0, 0, WND_W, TOP_BAR};
        FillRect(hdcMem, &rcBar, hBrushGold);

        /* title */
        DrawCentred(hdcMem, L"JEWLESS SOCIETY",
                    Y_LOGO, hFontLogo, CLR_GOLD);

        /* subtitle */
        DrawCentred(hdcMem, L"Private Server  |  Direct Connect",
                    Y_TAGLINE, hFontSub, CLR_GREY);

        /* live server status row */
        {
            wchar_t  statusTxt[512];
            COLORREF statusCol;

            EnterCriticalSection(&g_srvLock);
            BOOL    checked    = g_srv.checked;
            BOOL    online     = g_srv.online;
            int     clients    = g_srv.clients;
            int     maxClients = g_srv.maxClients;
            wchar_t hostname[256];
            wcscpy_s(hostname, 256, g_srv.hostname);
            LeaveCriticalSection(&g_srvLock);

            if (!checked)
            {
                wcscpy_s(statusTxt, 512, L"Checking server...");
                statusCol = CLR_GREY;
            }
            else if (!online)
            {
                wcscpy_s(statusTxt, 512, L"\u25CF OFFLINE");
                statusCol = CLR_RED;
            }
            else
            {
                if (maxClients > 0 && hostname[0])
                    _snwprintf_s(statusTxt, 512, _TRUNCATE,
                        L"\u25CF ONLINE  -  %d / %d players  -  %s",
                        clients, maxClients, hostname);
                else if (maxClients > 0)
                    _snwprintf_s(statusTxt, 512, _TRUNCATE,
                        L"\u25CF ONLINE  -  %d / %d players",
                        clients, maxClients);
                else
                    _snwprintf_s(statusTxt, 512, _TRUNCATE,
                        L"\u25CF ONLINE  -  %d player%s",
                        clients, clients == 1 ? L"" : L"s");
                statusCol = CLR_GREEN;
            }

            DrawCentred(hdcMem, statusTxt, Y_STATUS, hFontStatus, statusCol);
        }

        /* thin gold divider */
        {
            HPEN hPen    = CreatePen(PS_SOLID, 1, CLR_GOLD);
            HPEN hOldPen = (HPEN)SelectObject(hdcMem, hPen);
            MoveToEx(hdcMem, 60,         Y_DIVIDER, NULL);
            LineTo  (hdcMem, WND_W - 60, Y_DIVIDER);
            SelectObject(hdcMem, hOldPen);
            DeleteObject(hPen);
        }

        /* action status row (set by SetStatusBar) */
        DrawCentred(hdcMem, g_statusBarText,
                    Y_STATUSBAR, hFontStatus, g_statusBarCol);

        /* bottom info bar: shows current target host:port + client exe */
        {
            RECT rcBottom = {0, Y_BOTTOMBAR, WND_W, WND_H};
            HBRUSH hDark  = CreateSolidBrush(CLR_BG2);
            FillRect(hdcMem, &rcBottom, hDark);
            DeleteObject(hDark);

            wchar_t bottom[600];
            _snwprintf_s(bottom, 600, _TRUNCATE,
                L"target: %hs:%hs   client: %s",
                g_cfgIp, g_cfgPort, g_cfgClientExe);
            DrawCentred(hdcMem, bottom,
                        Y_BOTTOMBAR + 8, hFontTarget, CLR_GREY);
        }

        /* blit */
        BitBlt(hdc, 0, 0, WND_W, WND_H, hdcMem, 0, 0, SRCCOPY);
        SelectObject(hdcMem, hOld);
        DeleteObject(hBmp);
        DeleteDC(hdcMem);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_DRAWITEM:
    {
        DRAWITEMSTRUCT *dis = (DRAWITEMSTRUCT *)lParam;
        switch (dis->CtlID)
        {
        case ID_BTN_CONNECT:
            DrawButton(dis, L"CONNECT TO SERVER",
                       CLR_GOLD, RGB(180, 148, 40), RGB(10, 10, 10));
            return TRUE;
        case ID_BTN_DEV:
            DrawButton(dis, L"DEV LAUNCH  (no host check)",
                       CLR_AMBER, RGB(200, 130, 25), RGB(10, 10, 10));
            return TRUE;
        case ID_BTN_SETTINGS:
            DrawButton(dis, L"Settings...",
                       CLR_GREYDK, RGB(40, 40, 40), CLR_WHITE);
            return TRUE;
        }
        break;
    }

    case WM_COMMAND:
        switch (LOWORD(wParam))
        {
        case ID_BTN_CONNECT:
            DoConnect(hwnd);
            return 0;
        case ID_BTN_DEV:
            DoDevLaunch(hwnd);
            return 0;
        case ID_BTN_SETTINGS:
            OpenSettings(hwnd);
            return 0;
        }
        return 0;

    case WM_CTLCOLORSTATIC:
    {
        HDC hdcCtl = (HDC)wParam;
        SetBkMode(hdcCtl, TRANSPARENT);
        SetTextColor(hdcCtl, CLR_WHITE);
        return (LRESULT)hBrushBg;
    }

    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE) DestroyWindow(hwnd);
        return 0;

    case WM_DESTROY:
        if (g_stopEvent) SetEvent(g_stopEvent);
        if (g_pollThread)
        {
            WaitForSingleObject(g_pollThread, 6000);
            CloseHandle(g_pollThread);
            g_pollThread = NULL;
        }
        if (g_stopEvent)
        {
            CloseHandle(g_stopEvent);
            g_stopEvent = NULL;
        }
        DeleteCriticalSection(&g_srvLock);

        if (hFontLogo)   DeleteObject(hFontLogo);
        if (hFontSub)    DeleteObject(hFontSub);
        if (hFontSmall)  DeleteObject(hFontSmall);
        if (hFontStatus) DeleteObject(hFontStatus);
        if (hFontTarget) DeleteObject(hFontTarget);
        if (hBrushBg)    DeleteObject(hBrushBg);
        if (hBrushGold)  DeleteObject(hBrushGold);

        PostQuitMessage(0);
        return 0;

    default: break;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

/* ------------------------------------------------------------------ */
/*   wWinMain                                                         */
/* ------------------------------------------------------------------ */
int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev,
                    LPWSTR lpCmd, int nShow)
{
    (void)hPrev; (void)lpCmd; (void)nShow;

    /* ---- Resolve launcher dir + ini path ---- */
    {
        wchar_t exePath[MAX_PATH] = {0};
        GetModuleFileNameW(NULL, exePath, MAX_PATH);

        wcsncpy_s(g_launcherDir, MAX_PATH, exePath, _TRUNCATE);
        wchar_t *last = wcsrchr(g_launcherDir, L'\\');
        if (last) *(last + 1) = L'\0';

        _snwprintf_s(g_iniPath, MAX_PATH, _TRUNCATE,
                     L"%sjewless_config.ini", g_launcherDir);
    }

    /* ---- Init state ---- */
    InitializeCriticalSection(&g_srvLock);
    ZeroMemory(&g_srv, sizeof(g_srv));
    g_stopEvent = CreateEventW(NULL, TRUE, FALSE, NULL);

    /* Common controls (for dialog edits/buttons) */
    {
        INITCOMMONCONTROLSEX icc = { sizeof(icc),
            ICC_STANDARD_CLASSES | ICC_WIN95_CLASSES };
        InitCommonControlsEx(&icc);
    }

    LoadConfig();

    /* ---- Register window class ---- */
    WNDCLASSEXW wc      = {0};
    wc.cbSize           = sizeof(wc);
    wc.lpfnWndProc      = WndProc;
    wc.hInstance        = hInst;
    wc.hCursor          = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground    = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName    = L"JewlessLauncherV3";
    wc.hIcon            = LoadIconW(NULL, IDI_APPLICATION);
    wc.hIconSm          = LoadIconW(NULL, IDI_APPLICATION);
    RegisterClassExW(&wc);

    /* Centre on primary monitor */
    int cx = (GetSystemMetrics(SM_CXSCREEN) - WND_W) / 2;
    int cy = (GetSystemMetrics(SM_CYSCREEN) - WND_H) / 2;

    g_hwnd = CreateWindowExW(
        WS_EX_APPWINDOW,
        L"JewlessLauncherV3",
        L"JEWLESS SOCIETY",
        WS_POPUP | WS_VISIBLE,
        cx, cy, WND_W, WND_H,
        NULL, NULL, hInst, NULL);

    if (!g_hwnd)
    {
        DeleteCriticalSection(&g_srvLock);
        if (g_stopEvent) CloseHandle(g_stopEvent);
        return 1;
    }

    /* Start poll thread (only if host is set to something non-trivial) */
    g_pollThread = CreateThread(NULL, 0, PollThread, NULL, 0, NULL);

    SetStatusBar(L"Ready.", CLR_GREY);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}
