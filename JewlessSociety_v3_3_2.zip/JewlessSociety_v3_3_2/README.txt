JEWLESS SOCIETY — v3.3.2 (2026-05-18)
======================================

What this fixes (vs v3.3 / v3.3.1)
------------------------------------
Both previous builds failed with:

  GTA5.exe - System Error
  "The code execution cannot proceed because version-real.DLL was not found."

Root cause: the hook was built with linker forwarders
(/EXPORT:name=version-real.name for MSVC, .drectve asm for MinGW).
Linker forwarders delegate export resolution to a companion DLL named
version-real.dll.  That companion DLL was never deployed, so Windows
aborted at loader time before GTA5.exe could start.

Fix in v3.3.2: the linker forwarder section is completely gone.
version.dll is now a self-contained proxy.  On DLL load it calls
  LoadLibraryW("C:\\Windows\\System32\\version.dll")
then resolves all 17 exports with GetProcAddress.  No companion DLL,
no version-real.dll, zero external dependencies.


What you MUST do to use this build
------------------------------------
The prebuilt/ folder contains a ready-to-run JewlessLauncher.exe but
NOT a prebuilt JewlessHook.dll.  You must build the hook from the
fixed source before running:

  Option A — MSVC (Developer Command Prompt):
    cl /O2 /LD JewlessHook.c /link winhttp.lib psapi.lib /OUT:JewlessHook.dll

  Option B — MinGW-w64:
    x86_64-w64-mingw32-gcc -O2 -shared -municode ^
        JewlessHook.c -o JewlessHook.dll ^
        -Wl,--enable-stdcall-fixup -lwinhttp -lpsapi

  Or run BUILD_ALL.bat in a Developer Command Prompt — it tries MSVC
  first and falls back to MinGW.

After building, put JewlessLauncher.exe, JewlessHook.dll, and
jewless_config.ini together in one folder and run JewlessLauncher.exe.


Files
------
  JewlessHook.c            - hook source (FIXED — self-contained proxy)
  JewlessLauncher_v3_3.c   - launcher source (unchanged from v3.3.1)
  jewless_config.ini        - your config (GTA5 path already set)
  BUILD_ALL.bat             - builds both; tries MSVC then MinGW fallback
  README.txt                - this file
  prebuilt/
    JewlessLauncher.exe     - ready to run
    (no prebuilt JewlessHook.dll — build from fixed source above)


Diagnostics
-----------
After a successful run, jewless_hook.log appears next to GTA5.exe.
It logs:
  - Whether the system version.dll loaded OK
  - Every WinHttp call: [PROXY] / [DISCARD] / [PASS]
  - Whether the IAT hooks installed (WinHttpConnect/OpenRequest/SendRequest)

If GTA5.exe still fails, check jewless_hook.log first — it will show
exactly how far the hook got before the process died.


Outstanding diagnostic question (still pending)
------------------------------------------------
When DEV LAUNCH triggers "Couldn't start the game" (if it still appears
after this build), what does the FXServer console at 127.0.0.1:30120 show?

  (a) Nothing       -> GTA5.exe dying pre-network (DRM/Social Club issue)
  (b) Failed attempt -> server received connection but rejected it
  (c) Partial handshake -> platform-tier response shape needs work

The hook log will also clarify which case you're in.
