/*
 * JewlessHook v3.3.2 (2026-05-18)
 *
 * Fix vs v3.3 / v3.3.1:
 *   The previous build used linker forwarders (/EXPORT:name=version-real.name
 *   for MSVC, .drectve asm for MinGW). Both require a companion DLL named
 *   version-real.dll to be present in the same directory as the binary that
 *   imports version.dll.  Since version-real.dll was never deployed, Windows
 *   aborted with "version-real.DLL was not found" before GTA5.exe could start.
 *
 *   Root cause: linker forwarders delegate resolution to an external DLL.
 *   Correct fix: load C:\Windows\System32\version.dll ourselves via
 *   LoadLibraryW and resolve every export with GetProcAddress.  Zero external
 *   DLL dependency.  Self-contained.
 *
 * Deployed as version.dll alongside the GTA5 Legacy client.  Forwards every
 * official version.dll export so the Windows loader is satisfied, then in
 * DllMain installs a WinHttp IAT redirector that rewrites platform-tier
 * hostnames (auth.cfx.re, licensing.cfx.re, runtime.fivem.net,
 * auth.fivem.net, policy.fivem.net, cfx.re) to the user-owned platform tier
 * (worker or localhost dev), and discards telemetry hosts.
 *
 *   - PROXY_DOMAINS   → routed to user's platform tier
 *   - DISCARD_DOMAINS → silently dropped (telemetry/crash/sentry)
 *   - all other hosts → pass through unchanged (Rockstar, etc.)
 *
 * Build (MinGW-w64, 64-bit):
 *   x86_64-w64-mingw32-gcc -O2 -shared -municode \
 *       JewlessHook.c -o JewlessHook.dll \
 *       -Wl,--enable-stdcall-fixup -lwinhttp -lpsapi
 *   (Launcher copies this to <client_dir>\version.dll on deploy.)
 *
 * Build (MSVC):
 *   cl /O2 /LD JewlessHook.c /link winhttp.lib psapi.lib /OUT:JewlessHook.dll
 */

#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winhttp.h>
#include <psapi.h>
#include <stdio.h>
#include <wchar.h>

/* ================================================================
 * Self-contained version.dll proxy
 *
 * Loads C:\Windows\System32\version.dll at runtime.
 * Resolves all 17 exports with GetProcAddress.
 * Each stub caches its function pointer on first call.
 *
 * No companion DLL.  No version-real.dll.  Zero external dep.
 * ================================================================ */

static HMODULE g_realVer = NULL;

static void LoadRealVersion(void) {
    if (g_realVer) return;
    wchar_t path[MAX_PATH];
    if (!GetSystemDirectoryW(path, MAX_PATH)) return;
    wcscat_s(path, MAX_PATH, L"\\version.dll");
    g_realVer = LoadLibraryW(path);
    /* If this fails every stub returns a safe 0/FALSE and we log it. */
}

static FARPROC VerProc(const char *name) {
    LoadRealVersion();
    return g_realVer ? GetProcAddress(g_realVer, name) : NULL;
}

/* ---------- typed stubs (correct signatures for all 17 exports) ----------
 *
 * Each uses a per-stub static pointer so the GetProcAddress lookup happens
 * exactly once.  Concurrent first-calls on the same stub are safe: both
 * threads get the same address (GetProcAddress is idempotent for a loaded
 * module), and the last write wins — value is identical either way.
 *
 * Typed stubs (rather than void(void) trampolines) are required for the
 * functions that have 5+ parameters (GetFileVersionInfoEx*, VerFindFile*,
 * VerInstallFile*) so that the compiler emits correct stack-parameter
 * forwarding on x64.
 */

__declspec(dllexport) BOOL WINAPI
GetFileVersionInfoA(LPCSTR n, DWORD h, DWORD l, LPVOID d) {
    typedef BOOL (WINAPI *F)(LPCSTR, DWORD, DWORD, LPVOID);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoA");
    return _f ? _f(n, h, l, d) : FALSE;
}

__declspec(dllexport) BOOL WINAPI
GetFileVersionInfoW(LPCWSTR n, DWORD h, DWORD l, LPVOID d) {
    typedef BOOL (WINAPI *F)(LPCWSTR, DWORD, DWORD, LPVOID);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoW");
    return _f ? _f(n, h, l, d) : FALSE;
}

__declspec(dllexport) BOOL WINAPI
GetFileVersionInfoByHandle(DWORD fl, HANDLE hf, DWORD l, LPVOID d) {
    typedef BOOL (WINAPI *F)(DWORD, HANDLE, DWORD, LPVOID);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoByHandle");
    return _f ? _f(fl, hf, l, d) : FALSE;
}

/* 5-param — typed correctly so x64 ABI forwards stack args properly */
__declspec(dllexport) BOOL WINAPI
GetFileVersionInfoExA(DWORD fl, LPCSTR n, DWORD h, DWORD l, LPVOID d) {
    typedef BOOL (WINAPI *F)(DWORD, LPCSTR, DWORD, DWORD, LPVOID);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoExA");
    return _f ? _f(fl, n, h, l, d) : FALSE;
}

__declspec(dllexport) BOOL WINAPI
GetFileVersionInfoExW(DWORD fl, LPCWSTR n, DWORD h, DWORD l, LPVOID d) {
    typedef BOOL (WINAPI *F)(DWORD, LPCWSTR, DWORD, DWORD, LPVOID);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoExW");
    return _f ? _f(fl, n, h, l, d) : FALSE;
}

__declspec(dllexport) DWORD WINAPI
GetFileVersionInfoSizeA(LPCSTR n, LPDWORD ph) {
    typedef DWORD (WINAPI *F)(LPCSTR, LPDWORD);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoSizeA");
    return _f ? _f(n, ph) : 0;
}

__declspec(dllexport) DWORD WINAPI
GetFileVersionInfoSizeW(LPCWSTR n, LPDWORD ph) {
    typedef DWORD (WINAPI *F)(LPCWSTR, LPDWORD);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoSizeW");
    return _f ? _f(n, ph) : 0;
}

__declspec(dllexport) DWORD WINAPI
GetFileVersionInfoSizeExA(DWORD fl, LPCSTR n, LPDWORD ph) {
    typedef DWORD (WINAPI *F)(DWORD, LPCSTR, LPDWORD);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoSizeExA");
    return _f ? _f(fl, n, ph) : 0;
}

__declspec(dllexport) DWORD WINAPI
GetFileVersionInfoSizeExW(DWORD fl, LPCWSTR n, LPDWORD ph) {
    typedef DWORD (WINAPI *F)(DWORD, LPCWSTR, LPDWORD);
    static F _f;
    if (!_f) _f = (F)VerProc("GetFileVersionInfoSizeExW");
    return _f ? _f(fl, n, ph) : 0;
}

/* 8-param — typed correctly */
__declspec(dllexport) DWORD WINAPI
VerFindFileA(DWORD uFlags, PCSTR szFileName, PCSTR szWinDir, PCSTR szAppDir,
             PSTR szCurDir, PUINT lpuCurDirLen, PSTR szDestDir, PUINT lpuDestDirLen) {
    typedef DWORD (WINAPI *F)(DWORD,PCSTR,PCSTR,PCSTR,PSTR,PUINT,PSTR,PUINT);
    static F _f;
    if (!_f) _f = (F)VerProc("VerFindFileA");
    return _f ? _f(uFlags,szFileName,szWinDir,szAppDir,
                   szCurDir,lpuCurDirLen,szDestDir,lpuDestDirLen) : 0;
}

__declspec(dllexport) DWORD WINAPI
VerFindFileW(DWORD uFlags, PCWSTR szFileName, PCWSTR szWinDir, PCWSTR szAppDir,
             PWSTR szCurDir, PUINT lpuCurDirLen, PWSTR szDestDir, PUINT lpuDestDirLen) {
    typedef DWORD (WINAPI *F)(DWORD,PCWSTR,PCWSTR,PCWSTR,PWSTR,PUINT,PWSTR,PUINT);
    static F _f;
    if (!_f) _f = (F)VerProc("VerFindFileW");
    return _f ? _f(uFlags,szFileName,szWinDir,szAppDir,
                   szCurDir,lpuCurDirLen,szDestDir,lpuDestDirLen) : 0;
}

__declspec(dllexport) DWORD WINAPI
VerInstallFileA(DWORD uFlags, PCSTR szSrcFileName, PCSTR szDestFileName,
                PCSTR szSrcDir, PCSTR szDestDir, PCSTR szCurDir,
                PSTR szTmpFile, PUINT lpuTmpFileLen) {
    typedef DWORD (WINAPI *F)(DWORD,PCSTR,PCSTR,PCSTR,PCSTR,PCSTR,PSTR,PUINT);
    static F _f;
    if (!_f) _f = (F)VerProc("VerInstallFileA");
    return _f ? _f(uFlags,szSrcFileName,szDestFileName,
                   szSrcDir,szDestDir,szCurDir,szTmpFile,lpuTmpFileLen) : 0;
}

__declspec(dllexport) DWORD WINAPI
VerInstallFileW(DWORD uFlags, PCWSTR szSrcFileName, PCWSTR szDestFileName,
                PCWSTR szSrcDir, PCWSTR szDestDir, PCWSTR szCurDir,
                PWSTR szTmpFile, PUINT lpuTmpFileLen) {
    typedef DWORD (WINAPI *F)(DWORD,PCWSTR,PCWSTR,PCWSTR,PCWSTR,PCWSTR,PWSTR,PUINT);
    static F _f;
    if (!_f) _f = (F)VerProc("VerInstallFileW");
    return _f ? _f(uFlags,szSrcFileName,szDestFileName,
                   szSrcDir,szDestDir,szCurDir,szTmpFile,lpuTmpFileLen) : 0;
}

__declspec(dllexport) DWORD WINAPI
VerLanguageNameA(DWORD wLang, PSTR szLang, DWORD nSize) {
    typedef DWORD (WINAPI *F)(DWORD, PSTR, DWORD);
    static F _f;
    if (!_f) _f = (F)VerProc("VerLanguageNameA");
    return _f ? _f(wLang, szLang, nSize) : 0;
}

__declspec(dllexport) DWORD WINAPI
VerLanguageNameW(DWORD wLang, PWSTR szLang, DWORD nSize) {
    typedef DWORD (WINAPI *F)(DWORD, PWSTR, DWORD);
    static F _f;
    if (!_f) _f = (F)VerProc("VerLanguageNameW");
    return _f ? _f(wLang, szLang, nSize) : 0;
}

__declspec(dllexport) BOOL WINAPI
VerQueryValueA(LPCVOID pBlock, LPCSTR lpSubBlock, LPVOID *lplpBuffer, PUINT puLen) {
    typedef BOOL (WINAPI *F)(LPCVOID, LPCSTR, LPVOID*, PUINT);
    static F _f;
    if (!_f) _f = (F)VerProc("VerQueryValueA");
    return _f ? _f(pBlock, lpSubBlock, lplpBuffer, puLen) : FALSE;
}

__declspec(dllexport) BOOL WINAPI
VerQueryValueW(LPCVOID pBlock, LPCWSTR lpSubBlock, LPVOID *lplpBuffer, PUINT puLen) {
    typedef BOOL (WINAPI *F)(LPCVOID, LPCWSTR, LPVOID*, PUINT);
    static F _f;
    if (!_f) _f = (F)VerProc("VerQueryValueW");
    return _f ? _f(pBlock, lpSubBlock, lplpBuffer, puLen) : FALSE;
}

/* ================================================================
 * Platform-tier redirect config
 * ================================================================ */

static const wchar_t WORKER_DOMAIN[] =
    L"jewless-society.YOUR-SUBDOMAIN.workers.dev";

static const wchar_t * const PROXY_DOMAINS[] = {
    L"auth.cfx.re",
    L"licensing.cfx.re",
    L"runtime.fivem.net",
    L"auth.fivem.net",
    L"policy.fivem.net",
    L"cfx.re",
    NULL
};

static const wchar_t * const DISCARD_DOMAINS[] = {
    L"telemetry.fivem.net",
    L"sentry.fivem.net",
    L"crash.fivem.net",
    NULL
};

/* ================================================================
 * Logging (append to jewless_hook.log next to the client EXE)
 * ================================================================ */

static HANDLE g_logH = INVALID_HANDLE_VALUE;

static void Logf(const char *fmt, ...) {
    if (g_logH == INVALID_HANDLE_VALUE) return;
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    int n = _vsnprintf_s(buf, sizeof(buf), _TRUNCATE, fmt, ap);
    va_end(ap);
    if (n > 0) {
        DWORD w;
        WriteFile(g_logH, buf, (DWORD)n, &w, NULL);
        WriteFile(g_logH, "\r\n", 2, &w, NULL);
    }
}

static void OpenLog(void) {
    wchar_t path[MAX_PATH];
    GetModuleFileNameW(NULL, path, MAX_PATH);
    wchar_t *slash = wcsrchr(path, L'\\');
    if (slash) *(slash + 1) = 0;
    wcscat_s(path, MAX_PATH, L"jewless_hook.log");
    g_logH = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ, NULL,
                         OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
}

/* ================================================================
 * Domain classification
 * ================================================================ */

typedef enum { DOM_PASS = 0, DOM_PROXY = 1, DOM_DISCARD = 2 } DomKind;

static DomKind ClassifyHost(const wchar_t *host) {
    if (!host) return DOM_PASS;
    for (int i = 0; DISCARD_DOMAINS[i]; i++)
        if (_wcsicmp(host, DISCARD_DOMAINS[i]) == 0) return DOM_DISCARD;
    for (int i = 0; PROXY_DOMAINS[i]; i++)
        if (_wcsicmp(host, PROXY_DOMAINS[i]) == 0) return DOM_PROXY;
    return DOM_PASS;
}

/* ================================================================
 * WinHttp IAT hook
 * ================================================================ */

typedef HINTERNET (WINAPI *PFN_WinHttpConnect)(
    HINTERNET, LPCWSTR, INTERNET_PORT, DWORD);
typedef HINTERNET (WINAPI *PFN_WinHttpOpenRequest)(
    HINTERNET, LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR*, DWORD);
typedef BOOL (WINAPI *PFN_WinHttpSendRequest)(
    HINTERNET, LPCWSTR, DWORD, LPVOID, DWORD, DWORD, DWORD_PTR);

static PFN_WinHttpConnect     real_WinHttpConnect     = NULL;
static PFN_WinHttpOpenRequest real_WinHttpOpenRequest = NULL;
static PFN_WinHttpSendRequest real_WinHttpSendRequest = NULL;

static void ResolveWinHttp(void) {
    HMODULE w = GetModuleHandleW(L"winhttp.dll");
    if (!w) w = LoadLibraryW(L"winhttp.dll");
    if (!w) return;
    real_WinHttpConnect     = (PFN_WinHttpConnect)
        GetProcAddress(w, "WinHttpConnect");
    real_WinHttpOpenRequest = (PFN_WinHttpOpenRequest)
        GetProcAddress(w, "WinHttpOpenRequest");
    real_WinHttpSendRequest = (PFN_WinHttpSendRequest)
        GetProcAddress(w, "WinHttpSendRequest");
}

/* Connection / request handle tracking table */
#define MAX_CONN 64
typedef struct {
    HINTERNET h;
    DomKind   kind;
    wchar_t   host[128];
} ConnRec;
static ConnRec         g_conns[MAX_CONN];
static CRITICAL_SECTION g_lock;

static void RememberConn(HINTERNET h, DomKind k, const wchar_t *host) {
    EnterCriticalSection(&g_lock);
    for (int i = 0; i < MAX_CONN; i++) {
        if (g_conns[i].h == NULL || g_conns[i].h == h) {
            g_conns[i].h    = h;
            g_conns[i].kind = k;
            wcsncpy_s(g_conns[i].host, 128, host ? host : L"", _TRUNCATE);
            LeaveCriticalSection(&g_lock);
            return;
        }
    }
    LeaveCriticalSection(&g_lock);
}

static DomKind LookupConn(HINTERNET h, wchar_t *hostOut, size_t cch) {
    EnterCriticalSection(&g_lock);
    for (int i = 0; i < MAX_CONN; i++) {
        if (g_conns[i].h == h) {
            if (hostOut) wcscpy_s(hostOut, cch, g_conns[i].host);
            DomKind k = g_conns[i].kind;
            LeaveCriticalSection(&g_lock);
            return k;
        }
    }
    LeaveCriticalSection(&g_lock);
    return DOM_PASS;
}

/* Hooked entry points */

static HINTERNET WINAPI Hook_WinHttpConnect(
    HINTERNET hSession, LPCWSTR pswzServerName,
    INTERNET_PORT nServerPort, DWORD dwReserved)
{
    if (!real_WinHttpConnect) ResolveWinHttp();
    if (!real_WinHttpConnect) return NULL;

    DomKind       k      = ClassifyHost(pswzServerName);
    LPCWSTR       target = pswzServerName;
    INTERNET_PORT port   = nServerPort;

    if (k == DOM_PROXY) {
        Logf("WinHttpConnect(\"%ls\") -> [PROXY] %ls",
             pswzServerName ? pswzServerName : L"(null)", WORKER_DOMAIN);
        target = WORKER_DOMAIN;
        port   = INTERNET_DEFAULT_HTTPS_PORT;
    } else if (k == DOM_DISCARD) {
        Logf("WinHttpConnect(\"%ls\") -> [DISCARD]",
             pswzServerName ? pswzServerName : L"(null)");
    } else {
        Logf("WinHttpConnect(\"%ls\") -> [PASS]",
             pswzServerName ? pswzServerName : L"(null)");
    }

    HINTERNET h = real_WinHttpConnect(hSession, target, port, dwReserved);
    if (h) RememberConn(h, k, pswzServerName);
    return h;
}

static HINTERNET WINAPI Hook_WinHttpOpenRequest(
    HINTERNET hConnect, LPCWSTR pwszVerb, LPCWSTR pwszObjectName,
    LPCWSTR pwszVersion, LPCWSTR pwszReferrer, LPCWSTR *ppwszAcceptTypes,
    DWORD dwFlags)
{
    if (!real_WinHttpOpenRequest) ResolveWinHttp();
    if (!real_WinHttpOpenRequest) return NULL;

    wchar_t host[128] = L"";
    DomKind k = LookupConn(hConnect, host, 128);
    HINTERNET h = real_WinHttpOpenRequest(hConnect, pwszVerb, pwszObjectName,
        pwszVersion, pwszReferrer, ppwszAcceptTypes, dwFlags);
    if (h) RememberConn(h, k, host);
    return h;
}

static BOOL WINAPI Hook_WinHttpSendRequest(
    HINTERNET hRequest, LPCWSTR pwszHeaders, DWORD dwHeadersLength,
    LPVOID lpOptional, DWORD dwOptionalLength, DWORD dwTotalLength,
    DWORD_PTR dwContext)
{
    if (!real_WinHttpSendRequest) ResolveWinHttp();
    if (!real_WinHttpSendRequest) return FALSE;

    wchar_t host[128] = L"";
    DomKind k = LookupConn(hRequest, host, 128);
    if (k == DOM_DISCARD) {
        Logf("WinHttpSendRequest [DISCARD] host=%ls", host);
        SetLastError(ERROR_SUCCESS);
        return TRUE;
    }
    return real_WinHttpSendRequest(hRequest, pwszHeaders, dwHeadersLength,
        lpOptional, dwOptionalLength, dwTotalLength, dwContext);
}

/* IAT patch: walk the main module's import table and replace
 * the three WinHttp entries with our hooks. */
static void PatchIATForModule(HMODULE mod) {
    if (!mod) return;
    BYTE *base = (BYTE*)mod;

    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;

    IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;

    IMAGE_DATA_DIRECTORY *dir =
        &nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir->VirtualAddress) return;

    IMAGE_IMPORT_DESCRIPTOR *imp =
        (IMAGE_IMPORT_DESCRIPTOR*)(base + dir->VirtualAddress);

    for (; imp->Name; imp++) {
        const char *dllName = (const char*)(base + imp->Name);
        if (_stricmp(dllName, "winhttp.dll") != 0) continue;

        IMAGE_THUNK_DATA *oft = (IMAGE_THUNK_DATA*)(base + imp->OriginalFirstThunk);
        IMAGE_THUNK_DATA *ft  = (IMAGE_THUNK_DATA*)(base + imp->FirstThunk);

        for (; oft->u1.AddressOfData; oft++, ft++) {
            if (oft->u1.Ordinal & IMAGE_ORDINAL_FLAG) continue;

            IMAGE_IMPORT_BY_NAME *ibn =
                (IMAGE_IMPORT_BY_NAME*)(base + oft->u1.AddressOfData);
            const char *fn = (const char*)ibn->Name;

            void *replacement = NULL;
            if      (!strcmp(fn, "WinHttpConnect"))
                replacement = (void*)Hook_WinHttpConnect;
            else if (!strcmp(fn, "WinHttpOpenRequest"))
                replacement = (void*)Hook_WinHttpOpenRequest;
            else if (!strcmp(fn, "WinHttpSendRequest"))
                replacement = (void*)Hook_WinHttpSendRequest;

            if (!replacement) continue;

            DWORD old;
            VirtualProtect(&ft->u1.Function, sizeof(void*), PAGE_READWRITE, &old);
            ft->u1.Function = (ULONGLONG)(ULONG_PTR)replacement;
            VirtualProtect(&ft->u1.Function, sizeof(void*), old, &old);
            Logf("IAT hook installed: %s", fn);
        }
    }
}

/* ================================================================
 * Initialisation (runs on a thread to avoid loader-lock issues)
 * ================================================================ */

static DWORD WINAPI InitThread(LPVOID p) {
    (void)p;
    OpenLog();
    Logf("--- JewlessHook v3.3.2 init ---");

    /* Eager load of the real version.dll so we can log success/failure
     * before GTA5 ever calls any version API. */
    LoadRealVersion();
    if (g_realVer)
        Logf("version.dll proxy: system DLL loaded OK");
    else
        Logf("version.dll proxy: ERROR - could not load system version.dll");

    InitializeCriticalSection(&g_lock);
    ResolveWinHttp();
    PatchIATForModule(GetModuleHandleW(NULL));
    Logf("--- JewlessHook ready ---");
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID r) {
    (void)h; (void)r;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        CreateThread(NULL, 0, InitThread, NULL, 0, NULL);
    }
    return TRUE;
}
