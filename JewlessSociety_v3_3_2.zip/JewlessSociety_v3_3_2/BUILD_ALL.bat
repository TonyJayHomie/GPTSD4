@echo off
setlocal EnableDelayedExpansion

REM ============================================================
REM JEWLESS SOCIETY - BUILD_ALL.bat (v3.3.2, 2026-05-18)
REM Builds JewlessLauncher.exe and JewlessHook.dll.
REM (Launcher deploys JewlessHook.dll to client dir as version.dll.)
REM
REM Tries MSVC first (cl.exe), then falls back to MinGW-w64.
REM ============================================================

cd /d "%~dp0"

echo.
echo === Attempting MSVC build ===
where cl >nul 2>nul
if !errorlevel! == 0 (
    cl /nologo /O2 /W3 JewlessLauncher_v3_3.c ^
       /link /SUBSYSTEM:WINDOWS ^
       comctl32.lib shlwapi.lib shell32.lib comdlg32.lib ^
       user32.lib gdi32.lib advapi32.lib ^
       /OUT:JewlessLauncher.exe
    if !errorlevel! neq 0 goto :try_mingw

    cl /nologo /O2 /LD JewlessHook.c ^
       /link winhttp.lib psapi.lib /OUT:JewlessHook.dll
    if !errorlevel! neq 0 goto :try_mingw
    goto :done
)

:try_mingw
echo.
echo === Falling back to MinGW-w64 ===
where x86_64-w64-mingw32-gcc >nul 2>nul
if !errorlevel! neq 0 (
    echo ERROR: neither MSVC cl.exe nor MinGW x86_64-w64-mingw32-gcc found.
    echo Install one and re-run.
    exit /b 1
)

x86_64-w64-mingw32-gcc -O2 -municode -mwindows ^
    JewlessLauncher_v3_3.c -o JewlessLauncher.exe ^
    -lcomctl32 -lshlwapi -lshell32 -lcomdlg32 ^
    -luser32 -lgdi32 -ladvapi32
if !errorlevel! neq 0 exit /b 1

x86_64-w64-mingw32-gcc -O2 -shared -municode ^
    JewlessHook.c -o JewlessHook.dll ^
    -Wl,--enable-stdcall-fixup -lwinhttp -lpsapi
if !errorlevel! neq 0 exit /b 1

:done
echo.
echo === Build complete ===
dir /b JewlessLauncher.exe JewlessHook.dll
echo.
echo Put JewlessLauncher.exe, JewlessHook.dll, and jewless_config.ini
echo together in one folder. Run JewlessLauncher.exe.
endlocal
