/*
 * JewlessHook v3.3 (2026-05-18)
 *
 * Deployed as version.dll alongside the GTA5 Legacy client. Forwards every
 * official version.dll export so Windows loader is satisfied, then in DllMain
 * installs a WinHttp IAT redirector that rewrites platform-tier hostnames
 * (auth.cfx.re, licensing.cfx.re, runtime.fivem.net, auth.fivem.net,
 * policy.fivem.net, cfx.re) to the user-owned platform tier (worker or
 * localhost dev), and discards telemetry hosts.
 *
 *   - PROXY_DOMAINS  → routed to user's platform tier
 *   - DISCARD_DOMAINS→ silently dropped (telemetry/crash/sentry)
 *   - all other hosts (e.g. rockstar.com) → pass through unchanged
 *
 * Build (MinGW-w64, 64-bit):
 *   x86_64-w64-mingw32-gcc -O2 -shared -municode \
 *       JewlessHook.c -o version.dll \
 *       -Wl,--enable-stdcall-fixup -lwinhttp -lpsapi
 *
 * Build (MSVC):
 *   cl /O2 /LD JewlessHook.c /link winhttp.lib psapi.lib /OUT:version.dll
 *
 * NOTE: Source filename remains JewlessHook.c / JewlessHook.dll for build
 * clarity; the launcher renames it to version.dll on deploy.
 */

#define UNICODE
#define _UNICODE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winhttp.h>
#include <psapi.h>
#include <stdio.h>
#include <wchar.h>

/* ---- forwarders for every real version.dll export ----
 * Using GCC/MinGW-friendly syntax that also works under MSVC's linker
 * directives. */
#if defined(_MSC_VER)
  #define FWD(name) __pragma(comment(linker, "/EXPORT:" #name "=version-real." #name))
  FWD(GetFileVersionInfoA)
  FWD(GetFileVersionInfoByHandle)
  FWD(GetFileVersionInfoExA)
  FWD(GetFileVersionInfoExW)
  FWD(GetFileVersionInfoSizeA)
  FWD(GetFileVersionInfoSizeExA)
  FWD(GetFileVersionInfoSizeExW)
  FWD(GetFileVersionInfoSizeW)
  FWD(GetFileVersionInfoW)
  FWD(VerFindFileA)
  FWD(VerFindFileW)
  FWD(VerInstallFileA)
  FWD(VerInstallFileW)
  FWD(VerLanguageNameA)
  FWD(VerLanguageNameW)
  FWD(VerQueryValueA)
  FWD(VerQueryValueW)
#else
  /* MinGW: emit asm directives that produce the same export forwards. */
  asm(".section .drectve\n"
      ".ascii \" -export:GetFileVersionInfoA=version-real.GetFileVersionInfoA\"\n"
      ".ascii \" -export:GetFileVersionInfoByHandle=version-real.GetFileVersionInfoByHandle\"\n"
      ".ascii \" -export:GetFileVersionInfoExA=version-real.GetFileVersionInfoExA\"\n"
      ".ascii \" -export:GetFileVersionInfoExW=version-real.GetFileVersionInfoExW\"\n"
      ".ascii \" -export:GetFileVersionInfoSizeA=version-real.GetFileVersionInfoSizeA\"\n"
      ".ascii \" -export:GetFileVersionInfoSizeExA=version-real.GetFileVersionInfoSizeExA\"\n"
      ".ascii \" -export:GetFileVersionInfoSizeExW=version-real.GetFileVersionInfoSizeExW\"\n"
      ".ascii \" -export:GetFileVersionInfoSizeW=version-real.GetFileVersionInfoSizeW\"\n"
      ".ascii \" -export:GetFileVersionInfoW=version-real.GetFileVersionInfoW\"\n"
      ".ascii \" -export:VerFindFileA=version-real.VerFindFileA\"\n"
      ".ascii \" -export:VerFindFileW=version-real.VerFindFileW\"\n"
      ".ascii \" -export:VerInstallFileA=version-real.VerInstallFileA\"\n"
      ".ascii \" -export:VerInstallFileW=version-real.VerInstallFileW\"\n"
      ".ascii \" -export:VerLanguageNameA=version-real.VerLanguageNameA\"\n"
      ".ascii \" -export:VerLanguageNameW=version-real.VerLanguageNameW\"\n"
      ".ascii \" -export:VerQueryValueA=version-real.VerQueryValueA\"\n"
      ".ascii \" -export:VerQueryValueW=version-real.VerQueryValueW\"\n");
#endif

/* ---- redirect targets ----
 * WORKER_DOMAIN — user-editable. For dev with FXServer on localhost, the
 * launcher already sends +connect 127.0.0.1:30120, and the hook's job is
 * specifically to relocate cfx.re's platform-membership tier to the user's
 * own platform tier. Until a worker is deployed, the placeholder remains.
 */
static const wchar_t WORKER_DOMAIN[] = L"jewless-society.YOUR-SUBDOMAIN.workers.dev";

static const wchar_t * const PROXY_DOMAINS[] = {
    L"auth.cfx.re",
    L"licensing.cfx.re",
    L"runtime.fivem.net",
    L"auth.fivem.net",
    L"policy.fivem.net",
    L"cfx.re",
    NULL
};

static const wchar_t * const DISCARD_DOMAINS[] = {
    L"telemetry.fivem.net",
    L"sentry.fivem.net",
    L"crash.fivem.net",
    NULL
};

/* ---- logging ---- */
static HANDLE g_logH = INVALID_HANDLE_VALUE;

static void Logf(const char *fmt, ...) {
    if (g_logH == INVALID_HANDLE_VALUE) return;
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    int n = _vsnprintf_s(buf, 1024, _TRUNCATE, fmt, ap);
    va_end(ap);
    if (n > 0) {
        DWORD w;
        WriteFile(g_logH, buf, (DWORD)n, &w, NULL);
        WriteFile(g_logH, "\r\n", 2, &w, NULL);
    }
}

static void OpenLog(void) {
    wchar_t path[MAX_PATH];
    GetModuleFileNameW(NULL, path, MAX_PATH);
    wchar_t *slash = wcsrchr(path, L'\\');
    if (slash) *(slash + 1) = 0;
    wcscat_s(path, MAX_PATH, L"jewless_hook.log");
    g_logH = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ, NULL,
                         OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
}

/* ---- domain classify ---- */
typedef enum { DOM_PASS = 0, DOM_PROXY = 1, DOM_DISCARD = 2 } DomKind;

static DomKind ClassifyHost(const wchar_t *host) {
    if (!host) return DOM_PASS;
    for (int i = 0; DISCARD_DOMAINS[i]; i++)
        if (_wcsicmp(host, DISCARD_DOMAINS[i]) == 0) return DOM_DISCARD;
    for (int i = 0; PROXY_DOMAINS[i]; i++)
        if (_wcsicmp(host, PROXY_DOMAINS[i]) == 0) return DOM_PROXY;
    return DOM_PASS;
}

/* ---- WinHttp IAT hook ----
 * We intercept WinHttpConnect / WinHttpOpenRequest / WinHttpSendRequest.
 * Resolution is lazy via GetProcAddress (real heavy clients sometimes
 * load winhttp dynamically), so we hook the IAT eagerly AND have a
 * fallback resolver if the import isn't bound. */

typedef HINTERNET (WINAPI *PFN_WinHttpConnect)(
    HINTERNET, LPCWSTR, INTERNET_PORT, DWORD);
typedef HINTERNET (WINAPI *PFN_WinHttpOpenRequest)(
    HINTERNET, LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR, LPCWSTR*, DWORD);
typedef BOOL (WINAPI *PFN_WinHttpSendRequest)(
    HINTERNET, LPCWSTR, DWORD, LPVOID, DWORD, DWORD, DWORD_PTR);

static PFN_WinHttpConnect     real_WinHttpConnect     = NULL;
static PFN_WinHttpOpenRequest real_WinHttpOpenRequest = NULL;
static PFN_WinHttpSendRequest real_WinHttpSendRequest = NULL;

static void ResolveWinHttp(void) {
    HMODULE w = GetModuleHandleW(L"winhttp.dll");
    if (!w) w = LoadLibraryW(L"winhttp.dll");
    if (!w) return;
    real_WinHttpConnect = (PFN_WinHttpConnect)
        GetProcAddress(w, "WinHttpConnect");
    real_WinHttpOpenRequest = (PFN_WinHttpOpenRequest)
        GetProcAddress(w, "WinHttpOpenRequest");
    real_WinHttpSendRequest = (PFN_WinHttpSendRequest)
        GetProcAddress(w, "WinHttpSendRequest");
}

/* Per-connection bookkeeping: we need to know what host a HINTERNET was
 * opened against so OpenRequest/SendRequest decisions are correct.
 * Minimal table — not lock-free, but good enough for launch-time traffic. */
#define MAX_CONN 64
typedef struct {
    HINTERNET h;
    DomKind   kind;
    wchar_t   host[128];
} ConnRec;
static ConnRec g_conns[MAX_CONN];
static CRITICAL_SECTION g_lock;

static void RememberConn(HINTERNET h, DomKind k, const wchar_t *host) {
    EnterCriticalSection(&g_lock);
    for (int i = 0; i < MAX_CONN; i++) {
        if (g_conns[i].h == NULL || g_conns[i].h == h) {
            g_conns[i].h = h;
            g_conns[i].kind = k;
            wcsncpy_s(g_conns[i].host, 128, host ? host : L"", _TRUNCATE);
            LeaveCriticalSection(&g_lock);
            return;
        }
    }
    LeaveCriticalSection(&g_lock);
}

static DomKind LookupConn(HINTERNET h, wchar_t *hostOut, size_t cch) {
    EnterCriticalSection(&g_lock);
    for (int i = 0; i < MAX_CONN; i++) {
        if (g_conns[i].h == h) {
            if (hostOut) wcscpy_s(hostOut, cch, g_conns[i].host);
            DomKind k = g_conns[i].kind;
            LeaveCriticalSection(&g_lock);
            return k;
        }
    }
    LeaveCriticalSection(&g_lock);
    return DOM_PASS;
}

/* ---- hooked entry points ---- */

static HINTERNET WINAPI Hook_WinHttpConnect(
    HINTERNET hSession, LPCWSTR pswzServerName,
    INTERNET_PORT nServerPort, DWORD dwReserved)
{
    if (!real_WinHttpConnect) ResolveWinHttp();
    if (!real_WinHttpConnect) return NULL;

    DomKind k = ClassifyHost(pswzServerName);
    LPCWSTR target = pswzServerName;
    INTERNET_PORT port = nServerPort;

    if (k == DOM_PROXY) {
        Logf("WinHttpConnect(\"%ls\", ...) -> [PROXY] %ls",
             pswzServerName ? pswzServerName : L"(null)", WORKER_DOMAIN);
        target = WORKER_DOMAIN;
        port = INTERNET_DEFAULT_HTTPS_PORT;
    } else if (k == DOM_DISCARD) {
        Logf("WinHttpConnect(\"%ls\", ...) -> [DISCARD]",
             pswzServerName ? pswzServerName : L"(null)");
        /* Still return a real handle so the caller continues, but tag it
         * DISCARD so SendRequest no-ops. */
    } else {
        Logf("WinHttpConnect(\"%ls\", ...) -> [PASS]",
             pswzServerName ? pswzServerName : L"(null)");
    }

    HINTERNET h = real_WinHttpConnect(hSession, target, port, dwReserved);
    if (h) RememberConn(h, k, pswzServerName);
    return h;
}

static HINTERNET WINAPI Hook_WinHttpOpenRequest(
    HINTERNET hConnect, LPCWSTR pwszVerb, LPCWSTR pwszObjectName,
    LPCWSTR pwszVersion, LPCWSTR pwszReferrer, LPCWSTR *ppwszAcceptTypes,
    DWORD dwFlags)
{
    if (!real_WinHttpOpenRequest) ResolveWinHttp();
    if (!real_WinHttpOpenRequest) return NULL;

    wchar_t host[128] = L"";
    DomKind k = LookupConn(hConnect, host, 128);
    HINTERNET h = real_WinHttpOpenRequest(hConnect, pwszVerb, pwszObjectName,
        pwszVersion, pwszReferrer, ppwszAcceptTypes, dwFlags);
    if (h) RememberConn(h, k, host);
    return h;
}

static BOOL WINAPI Hook_WinHttpSendRequest(
    HINTERNET hRequest, LPCWSTR pwszHeaders, DWORD dwHeadersLength,
    LPVOID lpOptional, DWORD dwOptionalLength, DWORD dwTotalLength,
    DWORD_PTR dwContext)
{
    if (!real_WinHttpSendRequest) ResolveWinHttp();
    if (!real_WinHttpSendRequest) return FALSE;

    wchar_t host[128] = L"";
    DomKind k = LookupConn(hRequest, host, 128);
    if (k == DOM_DISCARD) {
        Logf("WinHttpSendRequest [DISCARD] host=%ls", host);
        SetLastError(ERROR_SUCCESS);
        return TRUE; /* pretend success, no traffic */
    }
    return real_WinHttpSendRequest(hRequest, pwszHeaders, dwHeadersLength,
        lpOptional, dwOptionalLength, dwTotalLength, dwContext);
}

/* ---- IAT patch ---- */
static void PatchIATForModule(HMODULE mod) {
    if (!mod) return;
    BYTE *base = (BYTE*)mod;
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER*)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;
    IMAGE_DATA_DIRECTORY *dir =
        &nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!dir->VirtualAddress) return;

    IMAGE_IMPORT_DESCRIPTOR *imp =
        (IMAGE_IMPORT_DESCRIPTOR*)(base + dir->VirtualAddress);

    for (; imp->Name; imp++) {
        const char *dllName = (const char*)(base + imp->Name);
        if (_stricmp(dllName, "winhttp.dll") != 0) continue;

        IMAGE_THUNK_DATA *oft = (IMAGE_THUNK_DATA*)(base + imp->OriginalFirstThunk);
        IMAGE_THUNK_DATA *ft  = (IMAGE_THUNK_DATA*)(base + imp->FirstThunk);
        for (; oft->u1.AddressOfData; oft++, ft++) {
            if (oft->u1.Ordinal & IMAGE_ORDINAL_FLAG) continue;
            IMAGE_IMPORT_BY_NAME *ibn =
                (IMAGE_IMPORT_BY_NAME*)(base + oft->u1.AddressOfData);
            const char *fn = (const char*)ibn->Name;
            void *replacement = NULL;
            if      (!strcmp(fn, "WinHttpConnect"))     replacement = (void*)Hook_WinHttpConnect;
            else if (!strcmp(fn, "WinHttpOpenRequest")) replacement = (void*)Hook_WinHttpOpenRequest;
            else if (!strcmp(fn, "WinHttpSendRequest")) replacement = (void*)Hook_WinHttpSendRequest;
            if (!replacement) continue;

            DWORD old;
            VirtualProtect(&ft->u1.Function, sizeof(void*), PAGE_READWRITE, &old);
            ft->u1.Function = (ULONGLONG)(ULONG_PTR)replacement;
            VirtualProtect(&ft->u1.Function, sizeof(void*), old, &old);
            Logf("IAT hook installed: %s", fn);
        }
    }
}

static DWORD WINAPI InitThread(LPVOID p) {
    (void)p;
    OpenLog();
    Logf("--- JewlessHook init ---");
    InitializeCriticalSection(&g_lock);
    ResolveWinHttp();
    PatchIATForModule(GetModuleHandleW(NULL));
    Logf("--- JewlessHook ready ---");
    return 0;
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID r) {
    (void)h; (void)r;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        CreateThread(NULL, 0, InitThread, NULL, 0, NULL);
    }
    return TRUE;
}
