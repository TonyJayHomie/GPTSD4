/*
 * JewlessLauncher v3.3 (2026-05-18)
 *
 * Fixes vs v3.2 (driven by the bottom-status-bar error in user's screenshot:
 *   "Hook DLL not found at: C:\Users\Mustafa\Downloads\JewlessHook.dll"):
 *
 *   1. AUTO-DISCOVERY of the hook DLL when the configured path is missing.
 *      Searches in order:
 *        a) configured jewless_config.ini hook_dll (resolved)
 *        b) <launcher_dir>\JewlessHook.dll
 *        c) <launcher_dir>\version.dll
 *        d) <launcher_dir>\hook\JewlessHook.dll
 *        e) %USERPROFILE%\Downloads\JewlessHook.dll
 *        f) <launcher_dir>\..\JewlessHook.dll
 *      If found at a non-configured location, ini is auto-updated.
 *
 *   2. Clearer error reporting: lists every path tried.
 *
 *   3. Safe deploy: never overwrite version.dll.jewless-backup; detect
 *      "deploying onto self".
 *
 *   4. INI round-trip preserved.
 *
 *   5. DEV LAUNCH still skips host/port validation but STILL deploys the
 *      hook (architectural rule).
 *
 * Build (MinGW-w64):
 *   x86_64-w64-mingw32-gcc -O2 -municode -mwindows \
 *       JewlessLauncher_v3_3.c -o JewlessLauncher.exe \
 *       -lcomctl32 -lshlwapi -lshell32 -lcomdlg32 -luser32 -lgdi32 -ladvapi32
 *
 * Build (MSVC):
 *   cl /O2 /W3 JewlessLauncher_v3_3.c /link /SUBSYSTEM:WINDOWS \
 *       comctl32.lib shlwapi.lib shell32.lib comdlg32.lib user32.lib gdi32.lib advapi32.lib
 */

#ifndef UNICODE
#define UNICODE
#endif
#ifndef _UNICODE
#define _UNICODE
#endif
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlwapi.h>
#include <shlobj.h>
#include <commctrl.h>
#include <commdlg.h>
#include <stdio.h>
#include <wchar.h>

#define ID_BTN_CONNECT   1001
#define ID_BTN_DEV       1002
#define ID_BTN_SETTINGS  1003

#define ID_EDIT_IP       2001
#define ID_EDIT_PORT     2002
#define ID_EDIT_CLIENT   2003
#define ID_EDIT_HOOK     2004
#define ID_BTN_OK        2010
#define ID_BTN_CANCEL    2011
#define ID_BTN_BROWSE_C  2012
#define ID_BTN_BROWSE_H  2013

#define INI_FILE_NAME L"jewless_config.ini"
#define INI_SECTION   L"jewless"

typedef struct {
    wchar_t server_ip[64];
    wchar_t server_port[8];
    wchar_t client_exe[MAX_PATH];
    wchar_t hook_dll[MAX_PATH];
} Config;

static HWND   g_hMain   = NULL;
static HWND   g_hStatus = NULL;
static Config g_cfg;
static wchar_t g_launcherDir[MAX_PATH] = {0};
static wchar_t g_iniPath[MAX_PATH]     = {0};

/* ---------- utilities ---------- */

static void SetStatus(const wchar_t *fmt, ...) {
    wchar_t buf[2048];
    va_list ap;
    va_start(ap, fmt);
    _vsnwprintf_s(buf, 2048, _TRUNCATE, fmt, ap);
    va_end(ap);
    if (g_hStatus) SetWindowTextW(g_hStatus, buf);
}

static void GetLauncherDir(wchar_t *out, size_t cch) {
    wchar_t exe[MAX_PATH];
    GetModuleFileNameW(NULL, exe, MAX_PATH);
    wcscpy_s(out, cch, exe);
    PathRemoveFileSpecW(out);
}

static void ResolveRelative(const wchar_t *in, wchar_t *out, size_t cch) {
    if (in == NULL || in[0] == 0) { out[0] = 0; return; }
    if (PathIsRelativeW(in)) {
        wchar_t tmp[MAX_PATH];
        PathCombineW(tmp, g_launcherDir, in);
        wcscpy_s(out, cch, tmp);
    } else {
        wcscpy_s(out, cch, in);
    }
}

static BOOL FileExists(const wchar_t *p) {
    DWORD a = GetFileAttributesW(p);
    return (a != INVALID_FILE_ATTRIBUTES) && !(a & FILE_ATTRIBUTE_DIRECTORY);
}

static BOOL PathsEqualNoCase(const wchar_t *a, const wchar_t *b) {
    wchar_t fa[MAX_PATH], fb[MAX_PATH];
    if (!GetFullPathNameW(a, MAX_PATH, fa, NULL)) wcscpy_s(fa, MAX_PATH, a);
    if (!GetFullPathNameW(b, MAX_PATH, fb, NULL)) wcscpy_s(fb, MAX_PATH, b);
    return _wcsicmp(fa, fb) == 0;
}

/* ---------- INI ---------- */

static void LoadConfig(void) {
    GetPrivateProfileStringW(INI_SECTION, L"server_ip",   L"127.0.0.1",
        g_cfg.server_ip, 64, g_iniPath);
    GetPrivateProfileStringW(INI_SECTION, L"server_port", L"30120",
        g_cfg.server_port, 8, g_iniPath);
    GetPrivateProfileStringW(INI_SECTION, L"client_exe",  L"",
        g_cfg.client_exe, MAX_PATH, g_iniPath);
    GetPrivateProfileStringW(INI_SECTION, L"hook_dll",    L"JewlessHook.dll",
        g_cfg.hook_dll, MAX_PATH, g_iniPath);
}

static void SaveConfig(void) {
    WritePrivateProfileStringW(INI_SECTION, L"server_ip",   g_cfg.server_ip,   g_iniPath);
    WritePrivateProfileStringW(INI_SECTION, L"server_port", g_cfg.server_port, g_iniPath);
    WritePrivateProfileStringW(INI_SECTION, L"client_exe",  g_cfg.client_exe,  g_iniPath);
    WritePrivateProfileStringW(INI_SECTION, L"hook_dll",    g_cfg.hook_dll,    g_iniPath);
}

/* ---------- hook discovery (root-cause fix for screenshot bug) ---------- */

static BOOL DiscoverHookDll(wchar_t *found, wchar_t *tried, size_t tried_cch) {
    wchar_t cand[8][MAX_PATH];
    int n = 0;

    if (g_cfg.hook_dll[0]) {
        ResolveRelative(g_cfg.hook_dll, cand[n], MAX_PATH);
        n++;
    }
    PathCombineW(cand[n], g_launcherDir, L"JewlessHook.dll"); n++;
    PathCombineW(cand[n], g_launcherDir, L"version.dll");     n++;
    {
        wchar_t sub[MAX_PATH];
        PathCombineW(sub, g_launcherDir, L"hook");
        PathCombineW(cand[n], sub, L"JewlessHook.dll");
        n++;
    }
    {
        wchar_t up[MAX_PATH];
        if (SHGetFolderPathW(NULL, CSIDL_PROFILE, NULL, 0, up) == S_OK) {
            wchar_t dl[MAX_PATH];
            PathCombineW(dl, up, L"Downloads");
            PathCombineW(cand[n], dl, L"JewlessHook.dll");
            n++;
        }
    }
    {
        wchar_t up[MAX_PATH];
        wcscpy_s(up, MAX_PATH, g_launcherDir);
        PathRemoveFileSpecW(up);
        PathCombineW(cand[n], up, L"JewlessHook.dll");
        n++;
    }

    if (tried && tried_cch) tried[0] = 0;
    for (int i = 0; i < n; i++) {
        if (tried && tried_cch) {
            wcsncat_s(tried, tried_cch, L"  - ", _TRUNCATE);
            wcsncat_s(tried, tried_cch, cand[i], _TRUNCATE);
            wcsncat_s(tried, tried_cch, L"\n", _TRUNCATE);
        }
        if (FileExists(cand[i])) {
            wcscpy_s(found, MAX_PATH, cand[i]);
            return TRUE;
        }
    }
    return FALSE;
}

/* ---------- hook deploy ---------- */

static BOOL DeployHook(const wchar_t *hookSrc, const wchar_t *clientExe,
                       wchar_t *errOut, size_t errCch) {
    wchar_t clientDir[MAX_PATH];
    wcscpy_s(clientDir, MAX_PATH, clientExe);
    PathRemoveFileSpecW(clientDir);

    wchar_t target[MAX_PATH], backup[MAX_PATH];
    PathCombineW(target, clientDir, L"version.dll");
    PathCombineW(backup, clientDir, L"version.dll.jewless-backup");

    if (PathsEqualNoCase(hookSrc, target)) {
        return TRUE; /* already in place; no-op */
    }

    if (FileExists(target) && !FileExists(backup)) {
        if (!MoveFileExW(target, backup, MOVEFILE_REPLACE_EXISTING)) {
            _snwprintf_s(errOut, errCch, _TRUNCATE,
                L"Backup failed (err %lu) for %s", GetLastError(), target);
            return FALSE;
        }
    }

    if (!CopyFileW(hookSrc, target, FALSE)) {
        _snwprintf_s(errOut, errCch, _TRUNCATE,
            L"Hook copy failed (err %lu): %s -> %s",
            GetLastError(), hookSrc, target);
        return FALSE;
    }
    return TRUE;
}

/* ---------- launch ---------- */

static BOOL LaunchClient(BOOL devLaunch) {
    wchar_t clientExe[MAX_PATH];
    ResolveRelative(g_cfg.client_exe, clientExe, MAX_PATH);
    if (clientExe[0] == 0 || !FileExists(clientExe)) {
        SetStatus(L"Client EXE not found. Open Settings... and set client_exe.");
        return FALSE;
    }

    wchar_t hookSrc[MAX_PATH] = {0};
    wchar_t tried[2048] = {0};
    if (!DiscoverHookDll(hookSrc, tried, 2048)) {
        SetStatus(L"Hook DLL not found. Tried:\n%s"
                  L"Drop JewlessHook.dll next to JewlessLauncher.exe.",
                  tried);
        return FALSE;
    }

    /* persist discovered location if it differs from config */
    {
        wchar_t cfgResolved[MAX_PATH] = {0};
        if (g_cfg.hook_dll[0])
            ResolveRelative(g_cfg.hook_dll, cfgResolved, MAX_PATH);
        if (!PathsEqualNoCase(cfgResolved, hookSrc)) {
            wcscpy_s(g_cfg.hook_dll, MAX_PATH, hookSrc);
            SaveConfig();
        }
    }

    if (!devLaunch) {
        if (g_cfg.server_ip[0] == 0 || g_cfg.server_port[0] == 0) {
            SetStatus(L"Server IP/Port empty. Open Settings...");
            return FALSE;
        }
    }

    wchar_t err[512] = {0};
    if (!DeployHook(hookSrc, clientExe, err, 512)) {
        SetStatus(L"%s", err);
        return FALSE;
    }

    wchar_t clientDir[MAX_PATH];
    wcscpy_s(clientDir, MAX_PATH, clientExe);
    PathRemoveFileSpecW(clientDir);

    wchar_t cmdline[1024];
    _snwprintf_s(cmdline, 1024, _TRUNCATE,
        L"\"%s\" +connect %s:%s",
        clientExe, g_cfg.server_ip, g_cfg.server_port);

    STARTUPINFOW si = { sizeof(si) };
    PROCESS_INFORMATION pi = {0};
    BOOL ok = CreateProcessW(NULL, cmdline, NULL, NULL, FALSE,
                             0, NULL, clientDir, &si, &pi);
    if (!ok) {
        SetStatus(L"CreateProcess failed (err %lu) for %s",
                  GetLastError(), clientExe);
        return FALSE;
    }
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);

    if (devLaunch) {
        SetStatus(L"Dev launch: hook deployed (%s), client started.", hookSrc);
    } else {
        SetStatus(L"Connect: hook deployed (%s), client started -> %s:%s.",
                  hookSrc, g_cfg.server_ip, g_cfg.server_port);
    }
    return TRUE;
}

/* ---------- Settings window ---------- */

static BOOL g_settingsDone = FALSE;
static BOOL g_settingsSave = FALSE;

static LRESULT CALLBACK SettingsWndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_COMMAND) {
        int id = LOWORD(wp);
        if (id == ID_BTN_OK)     { g_settingsSave = TRUE; g_settingsDone = TRUE; return 0; }
        if (id == ID_BTN_CANCEL) { g_settingsDone = TRUE; return 0; }
        if (id == ID_BTN_BROWSE_C || id == ID_BTN_BROWSE_H) {
            int editId = (id == ID_BTN_BROWSE_C) ? ID_EDIT_CLIENT : ID_EDIT_HOOK;
            wchar_t buf[MAX_PATH] = {0};
            GetDlgItemTextW(h, editId, buf, MAX_PATH);
            OPENFILENAMEW ofn;
            ZeroMemory(&ofn, sizeof(ofn));
            ofn.lStructSize = sizeof(ofn);
            ofn.hwndOwner   = h;
            ofn.lpstrFilter = (id == ID_BTN_BROWSE_C)
                ? L"Executables\0*.exe\0All\0*.*\0"
                : L"DLL files\0*.dll\0All\0*.*\0";
            ofn.lpstrFile = buf;
            ofn.nMaxFile  = MAX_PATH;
            ofn.Flags     = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
            if (GetOpenFileNameW(&ofn))
                SetDlgItemTextW(h, editId, buf);
            return 0;
        }
    }
    if (msg == WM_CLOSE) { g_settingsDone = TRUE; return 0; }
    return DefWindowProcW(h, msg, wp, lp);
}

static void OpenSettingsDialog(HWND parent) {
    static BOOL registered = FALSE;
    if (!registered) {
        WNDCLASSW wc = {0};
        wc.lpfnWndProc   = SettingsWndProc;
        wc.hInstance     = GetModuleHandleW(NULL);
        wc.hCursor       = LoadCursorW(NULL, IDC_ARROW);
        wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
        wc.lpszClassName = L"JewlessSettings";
        RegisterClassW(&wc);
        registered = TRUE;
    }

    HWND dlg = CreateWindowExW(WS_EX_DLGMODALFRAME,
        L"JewlessSettings", L"JEWLESS — Settings",
        WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
        100, 100, 560, 260, parent, NULL, GetModuleHandleW(NULL), NULL);

    HFONT hf = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

    #define LBL(txt, y) do { \
        HWND _l = CreateWindowW(L"STATIC", txt, WS_CHILD|WS_VISIBLE, \
            16, (y), 90, 20, dlg, NULL, NULL, NULL); \
        SendMessageW(_l, WM_SETFONT, (WPARAM)hf, TRUE); } while(0)
    #define EDT(id, val, y, w) do { \
        HWND _e = CreateWindowW(L"EDIT", val, \
            WS_CHILD|WS_VISIBLE|WS_BORDER|WS_TABSTOP|ES_AUTOHSCROLL, \
            112, (y), (w), 22, dlg, (HMENU)(LONG_PTR)(id), NULL, NULL); \
        SendMessageW(_e, WM_SETFONT, (WPARAM)hf, TRUE); } while(0)
    #define BTN(id, txt, x, y, w, hh) do { \
        HWND _b = CreateWindowW(L"BUTTON", txt, \
            WS_CHILD|WS_VISIBLE|WS_TABSTOP|BS_PUSHBUTTON, \
            (x), (y), (w), (hh), dlg, (HMENU)(LONG_PTR)(id), NULL, NULL); \
        SendMessageW(_b, WM_SETFONT, (WPARAM)hf, TRUE); } while(0)

    LBL(L"Server IP",   16);  EDT(ID_EDIT_IP,     g_cfg.server_ip,   14, 200);
    LBL(L"Port",        46);  EDT(ID_EDIT_PORT,   g_cfg.server_port, 44, 80);
    LBL(L"Client EXE",  76);  EDT(ID_EDIT_CLIENT, g_cfg.client_exe,  74, 360);
                              BTN(ID_BTN_BROWSE_C, L"...", 484, 74, 40, 22);
    LBL(L"Hook DLL",   106);  EDT(ID_EDIT_HOOK,   g_cfg.hook_dll,   104, 360);
                              BTN(ID_BTN_BROWSE_H, L"...", 484, 104, 40, 22);

    BTN(ID_BTN_OK,     L"Save",   336, 180, 90, 28);
    BTN(ID_BTN_CANCEL, L"Cancel", 434, 180, 90, 28);

    EnableWindow(parent, FALSE);

    g_settingsDone = FALSE;
    g_settingsSave = FALSE;
    MSG msg;
    while (!g_settingsDone && GetMessageW(&msg, NULL, 0, 0)) {
        if (msg.message == WM_KEYDOWN && msg.wParam == VK_ESCAPE) {
            g_settingsDone = TRUE; break;
        }
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    if (g_settingsSave) {
        GetDlgItemTextW(dlg, ID_EDIT_IP,     g_cfg.server_ip,   64);
        GetDlgItemTextW(dlg, ID_EDIT_PORT,   g_cfg.server_port, 8);
        GetDlgItemTextW(dlg, ID_EDIT_CLIENT, g_cfg.client_exe,  MAX_PATH);
        GetDlgItemTextW(dlg, ID_EDIT_HOOK,   g_cfg.hook_dll,    MAX_PATH);
        SaveConfig();
    }

    EnableWindow(parent, TRUE);
    SetForegroundWindow(parent);
    DestroyWindow(dlg);

    #undef LBL
    #undef EDT
    #undef BTN
}

/* ---------- main window ---------- */

static LRESULT CALLBACK WndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: {
        HFONT hf = (HFONT)GetStockObject(DEFAULT_GUI_FONT);

        HWND title = CreateWindowW(L"STATIC", L"JEWLESS SOCIETY",
            WS_CHILD|WS_VISIBLE|SS_CENTER, 10, 10, 460, 28, h, NULL, NULL, NULL);
        SendMessageW(title, WM_SETFONT, (WPARAM)hf, TRUE);

        HWND sub = CreateWindowW(L"STATIC", L"Private Server | Direct Connect",
            WS_CHILD|WS_VISIBLE|SS_CENTER, 10, 40, 460, 18, h, NULL, NULL, NULL);
        SendMessageW(sub, WM_SETFONT, (WPARAM)hf, TRUE);

        HWND b1 = CreateWindowW(L"BUTTON", L"CONNECT TO SERVER",
            WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
            90, 90, 300, 36, h, (HMENU)(LONG_PTR)ID_BTN_CONNECT, NULL, NULL);
        SendMessageW(b1, WM_SETFONT, (WPARAM)hf, TRUE);

        HWND b2 = CreateWindowW(L"BUTTON", L"DEV LAUNCH (no host check)",
            WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
            90, 134, 300, 36, h, (HMENU)(LONG_PTR)ID_BTN_DEV, NULL, NULL);
        SendMessageW(b2, WM_SETFONT, (WPARAM)hf, TRUE);

        HWND b3 = CreateWindowW(L"BUTTON", L"Settings...",
            WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
            150, 178, 180, 28, h, (HMENU)(LONG_PTR)ID_BTN_SETTINGS, NULL, NULL);
        SendMessageW(b3, WM_SETFONT, (WPARAM)hf, TRUE);

        g_hStatus = CreateWindowW(L"STATIC",
            L"Ready. Drop JewlessHook.dll next to JewlessLauncher.exe.",
            WS_CHILD|WS_VISIBLE|SS_LEFT,
            10, 220, 460, 80, h, NULL, NULL, NULL);
        SendMessageW(g_hStatus, WM_SETFONT, (WPARAM)hf, TRUE);
        return 0;
    }
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_BTN_CONNECT:  LaunchClient(FALSE); return 0;
        case ID_BTN_DEV:      LaunchClient(TRUE);  return 0;
        case ID_BTN_SETTINGS: OpenSettingsDialog(h); LoadConfig(); return 0;
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(h, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, PWSTR cmd, int show) {
    (void)hPrev; (void)cmd;

    InitCommonControls();

    GetLauncherDir(g_launcherDir, MAX_PATH);
    PathCombineW(g_iniPath, g_launcherDir, INI_FILE_NAME);
    LoadConfig();

    WNDCLASSW wc = {0};
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"JewlessLauncherV33";
    RegisterClassW(&wc);

    g_hMain = CreateWindowExW(0, L"JewlessLauncherV33",
        L"JEWLESS SOCIETY - Launcher",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, 500, 350,
        NULL, NULL, hInst, NULL);

    ShowWindow(g_hMain, show);
    UpdateWindow(g_hMain);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}
