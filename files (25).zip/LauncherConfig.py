#!/usr/bin/env python3
"""
LauncherConfig.py — Runtime configurator for JewlessLauncher.exe
Prompts for server IP and port, patches a temp copy, and launches it.

Placeholders in the original binary:
  OFFSET 0x2A7C  →  Port       (ASCII, 6-byte slot incl. null)  default: "30120"
  OFFSET 0x2A82  →  Server IP  (ASCII, 20-byte slot incl. null) default: "YOUR.SERVER.IP.HERE"

The exe formats them as  port:ip  via  %hs:%hs  and launches .\client\FXClient.exe
"""

import os
import sys
import shutil
import subprocess
import tempfile

# ─── Binary layout constants ───────────────────────────────────────────────────
PORT_OFFSET   = 0x2A7C
PORT_SLOT     = 6        # 5 chars max + null
IP_OFFSET     = 0x2A82
IP_SLOT       = 20       # 19 chars max + null

ORIGINAL_PORT = b"30120\x00"
ORIGINAL_IP   = b"YOUR.SERVER.IP.HERE\x00"

EXE_NAME      = "JewlessLauncher.exe"
PATCHED_NAME  = "JewlessLauncher_configured.exe"


def find_exe():
    """Locate the original exe next to this script or in CWD."""
    candidates = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), EXE_NAME),
        os.path.join(os.getcwd(), EXE_NAME),
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


def validate_port(port_str):
    """Return True if port string is valid."""
    if not port_str.isdigit():
        return False
    port = int(port_str)
    if port < 1 or port > 65535:
        return False
    if len(port_str) > 5:
        return False
    return True


def validate_ip(ip_str):
    """Return True if IP/hostname fits the 19-char slot."""
    if len(ip_str) == 0:
        return False
    if len(ip_str) > 19:
        return False
    # Allow IPs and hostnames — no further validation needed
    return True


def patch_binary(src_path, dst_path, server_ip, server_port):
    """Read src exe, patch the two placeholders, write to dst."""
    with open(src_path, "rb") as f:
        data = bytearray(f.read())

    # Verify expected bytes at offsets (sanity check)
    if data[PORT_OFFSET:PORT_OFFSET + PORT_SLOT] != ORIGINAL_PORT:
        # Already patched or different build — try to patch anyway
        print("[!] Warning: port slot doesn't match expected default. Patching anyway.")

    if data[IP_OFFSET:IP_OFFSET + IP_SLOT] != ORIGINAL_IP:
        print("[!] Warning: IP slot doesn't match expected default. Patching anyway.")

    # Patch port (null-pad the slot)
    port_bytes = server_port.encode("ascii") + b"\x00" * (PORT_SLOT - len(server_port))
    data[PORT_OFFSET:PORT_OFFSET + PORT_SLOT] = port_bytes[:PORT_SLOT]

    # Patch IP (null-pad the slot)
    ip_bytes = server_ip.encode("ascii") + b"\x00" * (IP_SLOT - len(server_ip))
    data[IP_OFFSET:IP_OFFSET + IP_SLOT] = ip_bytes[:IP_SLOT]

    with open(dst_path, "wb") as f:
        f.write(data)

    return dst_path


def prompt_values():
    """Interactive prompts for server IP and port."""
    print("=" * 55)
    print("     LAUNCHER CONFIGURATOR")
    print("=" * 55)
    print()

    # Port
    while True:
        port = input("  Server Port [default: 30120]: ").strip()
        if port == "":
            port = "30120"
        if validate_port(port):
            break
        print(f"  [!] Invalid port. Must be 1-65535, max 5 digits.")

    # IP / hostname
    while True:
        ip = input("  Server IP   [default: 127.0.0.1]: ").strip()
        if ip == "":
            ip = "127.0.0.1"
        if validate_ip(ip):
            break
        print(f"  [!] Invalid. Must be 1-19 characters.")

    print()
    print(f"  Port:      {port}")
    print(f"  Server IP: {ip}")
    print(f"  Connect:   {port}:{ip}")
    print()

    return ip, port


def main():
    print()

    # Find the original exe
    exe_path = find_exe()
    if not exe_path:
        print(f"[!] Cannot find {EXE_NAME} in script directory or CWD.")
        print(f"    Place this script next to {EXE_NAME} and run again.")
        input("\nPress Enter to exit...")
        sys.exit(1)

    exe_dir = os.path.dirname(exe_path)
    print(f"[+] Found: {exe_path}")
    print()

    # Get user values
    server_ip, server_port = prompt_values()

    # Patch and save
    dst_path = os.path.join(exe_dir, PATCHED_NAME)
    patch_binary(exe_path, dst_path, server_ip, server_port)
    print(f"[+] Patched copy saved: {dst_path}")

    # Ask whether to launch
    launch = input("  Launch now? [Y/n]: ").strip().lower()
    if launch in ("", "y", "yes"):
        print(f"[+] Launching {PATCHED_NAME}...")
        try:
            subprocess.Popen(
                [dst_path],
                cwd=exe_dir,
                creationflags=0x00000008 if sys.platform == "win32" else 0  # DETACHED_PROCESS
            )
            print("[+] Launched. This configurator will now exit.")
        except Exception as e:
            print(f"[!] Failed to launch: {e}")
            print(f"    Run {PATCHED_NAME} manually from: {exe_dir}")
    else:
        print(f"[+] Done. Run {PATCHED_NAME} manually when ready.")

    print()
    input("Press Enter to exit...")


if __name__ == "__main__":
    main()
