@echo off
setlocal EnableDelayedExpansion
title BUILD - JewlessClient.c (Phase 1 stub)

echo.
echo ============================================================
echo  JEWLESS CLIENT - Phase 1 stub build
echo  JewlessClient.c -^> JewlessClient.exe
echo  Accepts +connect ^<host:port^>, shows it, exits cleanly
echo  No FiveM, no GTA5, no Rockstar dependency
echo ============================================================
echo.

set "VCVARS="
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" set "VSWHERE=%ProgramFiles%\Microsoft Visual Studio\Installer\vswhere.exe"

if exist "%VSWHERE%" (
    for /f "usebackq tokens=*" %%i in (
        `"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath 2^>nul`
    ) do (
        if exist "%%i\VC\Auxiliary\Build\vcvarsall.bat" (
            set "VCVARS=%%i\VC\Auxiliary\Build\vcvarsall.bat"
        )
    )
)

if not defined VCVARS (
    echo [ERROR] vcvarsall.bat not found. Install VS Build Tools with C++.
    pause
    exit /b 1
)

echo [OK] Found MSVC at: %VCVARS%
echo.
call "%VCVARS%" x64
if errorlevel 1 ( echo [ERROR] vcvarsall x64 failed. & pause & exit /b 1 )

cd /d "%~dp0"
if not exist "JewlessClient.c" (
    echo [ERROR] JewlessClient.c not found in %~dp0
    pause
    exit /b 1
)

if exist "JewlessClient.exe" (
    set "BACKUP=JewlessClient.exe.bak_%DATE:~-4%-%DATE:~4,2%-%DATE:~7,2%_%TIME:~0,2%-%TIME:~3,2%-%TIME:~6,2%"
    set "BACKUP=!BACKUP: =0!"
    copy /y "JewlessClient.exe" "!BACKUP!" >nul
    echo [INFO] Existing exe backed up as !BACKUP!
)

echo [BUILD] Compiling...
cl /O2 /W3 /nologo /DUNICODE /D_UNICODE JewlessClient.c ^
    /link /SUBSYSTEM:WINDOWS /OUT:JewlessClient.exe ^
    user32.lib gdi32.lib shell32.lib

if %ERRORLEVEL% neq 0 ( echo [ERROR] Build failed. & pause & exit /b 1 )

for %%f in ("JewlessClient.exe") do set "SZ=%%~zf"
echo.
echo ============================================================
echo  BUILD SUCCEEDED  -  JewlessClient.exe (%SZ% bytes)
echo  Point the launcher's Client EXE field at this file.
echo  Then click LAUNCH in the DEV BYPASS panel.
echo ============================================================
pause
exit /b 0
