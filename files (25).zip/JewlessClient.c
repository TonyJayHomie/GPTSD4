/*
 * JewlessClient.c  --  Phase 1 stub client for JewlessLauncher
 * ============================================================
 * Tiny standalone Win32 exe that accepts "+connect <host:port>"
 * and displays it in a window.  No FiveM, no GTA5, no Rockstar.
 *
 * Purpose: proves the launcher's CreateProcess + arg-passing
 *          chain end-to-end.  Replace with your real client once
 *          Phase 1 is verified.
 *
 * BUILD (MSVC Developer Command Prompt x64):
 *   cl /O2 /W3 /nologo /DUNICODE /D_UNICODE JewlessClient.c ^
 *       /link /SUBSYSTEM:WINDOWS /OUT:JewlessClient.exe ^
 *       user32.lib gdi32.lib
 *
 * BUILD (MinGW-w64):
 *   x86_64-w64-mingw32-gcc -O2 -Wall -DUNICODE -D_UNICODE \
 *       JewlessClient.c -o JewlessClient.exe \
 *       -mwindows -luser32 -lgdi32
 *
 * USAGE (from launcher dev bypass):
 *   Client EXE path: C:\path\to\JewlessClient.exe
 *   Bypass target:   127.0.0.1:30120
 *   --> launcher runs:  "JewlessClient.exe" +connect 127.0.0.1:30120
 *   --> this window pops up showing the connect target
 */

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <stdio.h>

#pragma comment(lib, "shell32.lib")

#define WND_W 520
#define WND_H 280

#define CLR_BG       RGB( 10,  10,  10)
#define CLR_GOLD     RGB(212, 175,  55)
#define CLR_AMBER    RGB(255, 170,  40)
#define CLR_WHITE    RGB(255, 255, 255)
#define CLR_GREEN    RGB( 90, 220, 110)
#define CLR_GREY     RGB(140, 140, 140)

static wchar_t g_connect[512] = L"(no +connect argument received)";
static BOOL    g_haveConnect  = FALSE;
static HFONT   g_fontTitle    = NULL;
static HFONT   g_fontMono     = NULL;
static HFONT   g_fontLabel    = NULL;

static void ParseArgs(void)
{
    int argc = 0;
    LPWSTR *argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv) return;

    for (int i = 1; i < argc - 1; ++i) {
        if (lstrcmpiW(argv[i], L"+connect") == 0) {
            wcsncpy(g_connect, argv[i + 1],
                    sizeof(g_connect) / sizeof(wchar_t) - 1);
            g_connect[sizeof(g_connect) / sizeof(wchar_t) - 1] = L'\0';
            g_haveConnect = TRUE;
            break;
        }
    }
    LocalFree(argv);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
    switch (msg) {
    case WM_CREATE: {
        g_fontTitle = CreateFontW(28, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");
        g_fontMono  = CreateFontW(20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_MODERN, L"Consolas");
        g_fontLabel = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_SWISS, L"Segoe UI");

        HWND btn = CreateWindowExW(0, L"BUTTON", L"Close",
            WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON,
            (WND_W - 120) / 2, WND_H - 70, 120, 32,
            hwnd, (HMENU)(UINT_PTR)1, GetModuleHandle(NULL), NULL);
        SendMessageW(btn, WM_SETFONT, (WPARAM)g_fontLabel, FALSE);
        return 0;
    }

    case WM_COMMAND:
        if (LOWORD(wp) == 1) DestroyWindow(hwnd);
        return 0;

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC dc = BeginPaint(hwnd, &ps);
        RECT rc; GetClientRect(hwnd, &rc);

        HBRUSH bgBr = CreateSolidBrush(CLR_BG);
        FillRect(dc, &rc, bgBr);
        DeleteObject(bgBr);

        RECT bar = {0, 0, rc.right, 4};
        HBRUSH barBr = CreateSolidBrush(CLR_GOLD);
        FillRect(dc, &bar, barBr);
        DeleteObject(barBr);

        SetBkMode(dc, TRANSPARENT);

        SelectObject(dc, g_fontTitle);
        SetTextColor(dc, CLR_GOLD);
        RECT rcT = {0, 28, rc.right, 70};
        DrawTextW(dc, L"JEWLESS CLIENT  (Phase 1 stub)", -1, &rcT,
                  DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        SelectObject(dc, g_fontLabel);
        SetTextColor(dc, CLR_GREY);
        RECT rcL = {0, 80, rc.right, 100};
        DrawTextW(dc, L"Connect target received from launcher:", -1, &rcL,
                  DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        SelectObject(dc, g_fontMono);
        SetTextColor(dc, g_haveConnect ? CLR_GREEN : CLR_AMBER);
        RECT rcC = {0, 110, rc.right, 150};
        DrawTextW(dc, g_connect, -1, &rcC,
                  DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        SelectObject(dc, g_fontLabel);
        SetTextColor(dc, CLR_GREY);
        RECT rcF = {0, 160, rc.right, 190};
        DrawTextW(dc,
            g_haveConnect
              ? L"Launcher -> CreateProcess -> arg passthrough: OK"
              : L"No +connect arg. Run me from the launcher's DEV BYPASS.",
            -1, &rcF, DT_CENTER | DT_VCENTER | DT_SINGLELINE);

        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_DESTROY:
        DeleteObject(g_fontTitle);
        DeleteObject(g_fontMono);
        DeleteObject(g_fontLabel);
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR cmd, int nShow)
{
    (void)hPrev; (void)cmd;

    ParseArgs();

    WNDCLASSEXW wc = {0};
    wc.cbSize        = sizeof(wc);
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInst;
    wc.hCursor       = LoadCursorW(NULL, (LPCWSTR)IDC_ARROW);
    wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wc.lpszClassName = L"JewlessClient";
    wc.hIcon         = LoadIconW(NULL, (LPCWSTR)IDI_APPLICATION);
    RegisterClassExW(&wc);

    int sw = GetSystemMetrics(SM_CXSCREEN);
    int sh = GetSystemMetrics(SM_CYSCREEN);

    HWND hwnd = CreateWindowExW(
        WS_EX_APPWINDOW, L"JewlessClient", L"JEWLESS CLIENT",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        (sw - WND_W) / 2, (sh - WND_H) / 2, WND_W, WND_H,
        NULL, NULL, hInst, NULL);

    ShowWindow(hwnd, nShow);
    UpdateWindow(hwnd);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}
