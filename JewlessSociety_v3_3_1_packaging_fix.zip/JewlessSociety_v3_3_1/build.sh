#!/usr/bin/env bash
set -euo pipefail
CC="${CC:-x86_64-w64-mingw32-gcc}"
OUTDIR="${1:-prebuilt}"
mkdir -p "$OUTDIR"
"$CC" -O2 -municode -mwindows \
  JewlessLauncher_v3_3.c -o "$OUTDIR/JewlessLauncher.exe" \
  -lcomctl32 -lshlwapi -lshell32 -lcomdlg32 -luser32 -lgdi32 -ladvapi32
"$CC" -O2 -shared -municode \
  JewlessHook.c -o "$OUTDIR/JewlessHook.dll" \
  -Wl,--enable-stdcall-fixup -lwinhttp -lpsapi
cp "$OUTDIR/JewlessHook.dll" "$OUTDIR/version.dll"
echo "Built into $OUTDIR/"
ls -la "$OUTDIR/"
