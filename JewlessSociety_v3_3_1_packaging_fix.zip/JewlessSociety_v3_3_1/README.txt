JEWLESS SOCIETY — v3.3 (2026-05-18)
====================================

What changed since v3.2
-----------------------
The status-bar error "Hook DLL not found at C:\Users\Mustafa\Downloads\
JewlessHook.dll" was caused by the launcher reading a stale absolute path
in jewless_config.ini and refusing to look anywhere else. v3.3 now:

  1. Auto-discovers JewlessHook.dll in 6 well-known locations.
     If found anywhere other than the configured path, the new location
     is auto-saved to jewless_config.ini for next time.

  2. If still not found, the status bar lists every path that was tried
     so you know exactly where to drop the file.

  3. Hardens DeployHook against the "deploy onto itself" edge case and
     never overwrites version.dll.jewless-backup.

  4. Same architectural behavior as v3.2:
       - CONNECT and DEV LAUNCH both deploy the hook (every launch).
       - DEV LAUNCH only skips host/port validation.
       - No MessageBox popups; all errors go to the status bar.

Files
-----
  JewlessLauncher_v3_3.c  - launcher source (single file, MSVC + MinGW)
  JewlessHook.c           - hook source (single file, MSVC + MinGW)
  jewless_config.ini      - editable config, also editable from Settings…
  BUILD_ALL.bat           - tries MSVC, falls back to MinGW-w64
  README.txt              - this file

Quick start
-----------
  1. Run BUILD_ALL.bat in a Developer Command Prompt (MSVC) or a shell
     with MinGW-w64 on PATH.
  2. Put JewlessLauncher.exe, JewlessHook.dll, and jewless_config.ini
     together in any folder. (The launcher will find JewlessHook.dll
     wherever it is — see auto-discovery above — but co-located is
     cleanest.)
  3. Run JewlessLauncher.exe.

About the "Couldn't start the game" popup
-----------------------------------------
That dialog is from GTA5.exe itself, not from JewlessLauncher.exe (the
launcher has no MessageBox imports — verified with objdump). Diagnostic
question still pending: when DEV LAUNCH triggers that popup, what does
FXServer console at 127.0.0.1:30120 show?

   (a) nothing            → GTA5 dies pre-network (Social Club / DRM /
                            asset loader issue, not the hook/server)
   (b) connection-attempt → server received something but rejected it
   (c) partial handshake  → platform-tier response shape needs work

The hook writes jewless_hook.log next to the client EXE on every run,
which will show which case you're in.

Packaging note (v3.3.1)
----------------------
This package now also includes:
  - prebuilt/version.dll   (ready-to-drop runtime deploy name)
  - build.sh               (MinGW reproducible build script)
  - Makefile               (MinGW reproducible build target)
